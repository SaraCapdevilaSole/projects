"""
Cross - section (section 5)
"""
import numpy as np
import matplotlib.pyplot as plt
import CP1_tools

#%%
theta_23 = np.pi/4 #rads
dm_23_squ = 2.4e-3 #(eV)^2 #as theta increase oscillation increases through a larger range of Energies
L = 295 #Km

E_max = 10 #GeV
E_min = 0
N = 200
dE = (E_max - E_min) / N
E = np.arange(E_min + dE, E_max + dE, dE)
data = CP1_tools.open_file("Data to Fit")

P_mu = []
for E_i in E:
    P_mu.append(CP1_tools.oscillation_prob(theta_23, dm_23_squ, L, E_i))

Un_Osc_ev = CP1_tools.open_file("Unoscillated Events")

#oscillated event rate prediction: Osc_ev = lambda_i
Osc_ev = CP1_tools.Oscillated_converter(P_mu, Un_Osc_ev) #oscillates events from simulated unoscillated event data * P_mu

#CP1_tools.plot_event(E, Un_Osc_ev, "Energy (GeV)", "Events", "Unoscillated event prediction")
CP1_tools.plot_event([], [], "Energy (GeV)", "Number of events (N)", "")
plt.plot(E, Osc_ev, label = "Oscillated event prediction ($\lambda_i$)", color = "black", linewidth = 3)


alpha = [0.1, 1.0, 1.5, 2.0, 2.5]

colours = ["yellow", "orange", "red", "blue","#1a7100", "black"]

lambda_new = []
for i in range(len(alpha)):
    lambda_new.append(CP1_tools.Predict_lambda_i(theta_23, dm_23_squ, alpha[i]))
    
for i in range(len(alpha)):
    CP1_tools.plot_event([], [], "Energy (GeV)", "Number of events (N)", "")
    plt.plot(E, lambda_new[i], '--',label= "$\lambda_i$($\u03B1$ = {})".format(alpha[i]), color = colours[i])

data = CP1_tools.open_file("Data to Fit")

plt.bar(x = E, height = data, width = 0.05, label = "Observed data $(m_i)$", color = "grey")
#plt.plot(E, data, label = "Data $(m_i)$")
plt.legend()
#%%
alpha = np.linspace(0,5,100)
NLL_tot = [CP1_tools.NLL_3D(theta_23, dm_23_squ, i) for i in alpha]
CP1_tools.plot_event(alpha, NLL_tot, "\u03B1", "$\it{NLL}$", "")
#%% - Gradient method with momentum
theta, mass, alpha = [0.5, 0.002, 1]
x_minGm, theta_Gm, mass_Gm, alpha_Gm  = CP1_tools.Gradient_method2_3D(theta, mass, alpha, momentum = 0.5)

#%%
NLL_grad_m = [CP1_tools.NLL_3D(theta_Gm[i], mass_Gm[i], alpha_Gm[i]) for i in range(len(theta_Gm))]

#%%
from mpl_toolkits import mplot3d
fig = plt.figure(figsize = (10, 7))
ax = plt.axes(projection ="3d")
 
# Creating plot
a = ax.scatter3D(theta_Gm, mass_Gm, alpha_Gm, cmap = "jet")
#(a, label="NLL")
fig.show()
#%%
print(CP1_tools.Parabolic_error_3D(x_minGm[0] - 0.1, x_minGm[0],x_minGm[0],x_minGm[0] + 0.1,x_minGm[0],x_minGm[1],x_minGm[2], "theta"))
print(CP1_tools.Parabolic_error_3D(x_minGm[1] - 1e-4, x_minGm[1],x_minGm[1],x_minGm[1] + 1e-4,x_minGm[0],x_minGm[1],x_minGm[2], "mass"))
print(CP1_tools.Parabolic_error_3D(x_minGm[2] - 0.1, x_minGm[2],x_minGm[2],x_minGm[2] + 0.1,x_minGm[2],x_minGm[1],x_minGm[2], "alpha"))
"""
Gradient with Momentum p = 0.85: 2683
[0.7086174700156986, -0.01238566731607127, 0.012928335842343652]
[0.0027425915018231863, -3.8267088641700565e-05, 3.7968034844694173e-05]
[1.2652910365542671, -0.001089830133448766, 0.0010898301332789018] - the error is now a lot larger for alpha
"""
#%% - Average Gradient in 3D
theta, mass, alpha = [0.5, 0.002, 1]
x_minG, theta_G, mass_G, alpha_G = CP1_tools.Gradient_method_3D(theta, mass, alpha)
#19418 [0.70878866 0.00274264 1.26664416]
#%%
NLL_grad = [CP1_tools.NLL_3D(theta_G[i], mass_G[i], alpha_G[i]) for i in range(len(theta_G))]
#%%
from mpl_toolkits import mplot3d
fig = plt.figure(figsize = (10, 7))
ax = plt.axes(projection ="3d")
 
# Creating plot
a = ax.scatter3D(theta_G, mass_G, alpha_G, cmap = "jet")
#(a, label="NLL")
fig.show()
#%%
fig, axs = plt.subplots(3, sharex = True)
plt.subplots_adjust(hspace=0.1, top = 1.3)

axs[0].plot(theta_G, label = "Gradient")
axs[0].plot(theta_Gm, label = "Gradient with $p=0.8$")
axs[0].plot([0,len(theta_G)],[theta_G[-1], theta_G[-1]], "--",color = "grey", alpha = 0.5)
plt.legend()
axs[0].grid()
axs[0].set_ylabel('$\u03F4_{23}$')
fig.legend(loc="center right")

axs[2].plot(alpha_G, label = "Gradient")
axs[2].plot(alpha_Gm, label = "Gradient with $p=0.85$")
axs[2].plot([0,len(alpha_G)],[alpha_G[-1], alpha_G[-1]], "--",color = "grey", alpha = 0.5)
axs[1].grid()
axs[2].set_ylabel("$\u03B1$")
axs[2].set_ylim([0.8,1.4])

axs[1].plot(mass_G, label = "Gradient")
axs[1].plot(mass_Gm, label = "Gradient with $p=0.85$")
axs[1].plot([0,len(mass_G)],[mass_G[-1], mass_G[-1]], "--",color = "grey", alpha = 0.5)
axs[1].set_ylim([0.0025,0.0028])
axs[2].grid()
axs[2].set_xlabel("Iteration")
axs[1].set_ylabel('$\u0394 m^{2}_{23}$')

#%%
print(CP1_tools.Parabolic_error_3D(x_minG[0] - 0.1, x_minG[0],x_minG[0],x_minG[0] + 0.1,x_minG[0],x_minG[1],x_minG[2], "theta"))
print(CP1_tools.Parabolic_error_3D(x_minG[1] - 1e-4, x_minG[1],x_minG[1],x_minG[1] + 1e-4,x_minG[0],x_minG[1],x_minG[2], "mass"))
print(CP1_tools.Parabolic_error_3D(x_minG[2] - 0.1, x_minG[2],x_minG[2],x_minG[2] + 0.1,x_minG[2],x_minG[1],x_minG[2], "alpha"))
"""Gradient method: 19418
[0.7087887640244479, -0.012455226636619132, 0.012843428929665612]
[0.0027426424454960775, -3.8243427209695875e-05, 3.794505373708786e-05]
[1.2666449564191815, 0.0010845233339700222, 0.0010845233338070415]"""
#%%
#alpha_array = np.linspace(0,2,100)
mass_array = np.linspace(1e-3, 3e-3, 100)
y = [CP1_tools.NLL_function_err_3D(x_minG[0], m, x_minG[2], x_minG[0], x_minG[1], x_minG[2]) for m in mass_array]
plt.plot(mass_array, y)
plt.ylim([-1,1])
plt.xlim([0.0026, 0.0028])
plt.grid()
#%%
theta, mass, alpha = [0.5, 0.002, 1]
x_QN, theta_QN, mass_QN, alpha_QN = CP1_tools.Newton_Quasi_3D(theta, mass, alpha)
#8001 [0.70861628 0.00274262 1.27108701]
#%%
NLL_QN = [CP1_tools.NLL_3D(theta_QN[i], mass_QN[i], alpha_QN[i]) for i in range(len(theta_QN))]
#%%
print(CP1_tools.Parabolic_error_3D(x_QN[0] - 0.1, x_QN[0],x_QN[0],x_QN[0] + 0.1,x_QN[0],x_QN[1],x_QN[2], "theta"))
print(CP1_tools.Parabolic_error_3D(x_QN[1] - 1e-4, x_QN[1],x_QN[1],x_QN[1] + 1e-4,x_QN[0],x_QN[1],x_QN[2], "mass"))
print(CP1_tools.Parabolic_error_3D(x_QN[2] - 0.1, x_QN[2],x_QN[2],x_QN[2] + 0.1,x_QN[2],x_QN[1],x_QN[2], "alpha"))
"""
Quasi Newton: 8001
[0.7086162798065545, -0.011973785753159105, 0.013310777365799997]
[0.0027426224378992777, -3.821978964254442e-05, 3.792197521726177e-05]
[1.2710870066068625, 0.001067542305115854, 0.0010675423049733013]
"""
#%%
fig = plt.figure(figsize = (10, 7))
ax = plt.axes(projection ="3d")
ax.scatter3D(theta_QN, mass_QN, alpha_QN, cmap = "jet")

#%%
theta, mass, alpha = [0.72, 0.0025, 1.25]
x_min, theta_N, mass_N, alpha_N = CP1_tools.Newton_3D(theta, mass, alpha)
#5059 [0.70904968 0.00274142 1.26972809]
#%%
from mpl_toolkits import mplot3d
fig = plt.figure(figsize = (10, 7))
ax = plt.axes(projection ="3d")
 
# Creating plot
a = ax.scatter3D(theta_N, mass_N, alpha_N, cmap = "jet")
#(a, label="NLL")
fig.show()

#%%
print(CP1_tools.Parabolic_error_3D(x_min[0] - 0.1, x_min[0],x_min[0],x_min[0] + 0.1,x_min[0],x_min[1],x_min[2], "theta"))
print(CP1_tools.Parabolic_error_3D(x_min[1] - 2e-4, x_min[1],x_min[1],x_min[1] + 2e-4,x_min[0],x_min[1],x_min[2], "mass"))
print(CP1_tools.Parabolic_error_3D(x_min[2] - 0.1, x_min[2],x_min[2],x_min[2] + 0.1,x_min[2],x_min[1],x_min[2], "alpha"))
#%%
NLL_N = [CP1_tools.NLL_3D(theta_N[i], mass_N[i], alpha_N[i]) for i in range(len(theta_N))]
"""
Newton: 5059
[0.7090496797927822, -0.012519926507815526, 0.012735983012851504]
[0.002741418731617208, -3.69085108465712e-05, 3.923056429594018e-05]
[1.269728093103257, -0.0010726647120262722, 0.0010726647118781685]
"""
#%% - Newton 2 - this is the better function (modified newton method)
theta, mass, alpha = [0.5, 0.002, 1]#[0.6, 0.002, 1]
x_minm, theta_Nm, mass_Nm, alpha_Nm = CP1_tools.Newton2_3D(theta, mass, alpha)
#%%
from mpl_toolkits import mplot3d
fig = plt.figure(figsize = (10, 7))
ax = plt.axes(projection ="3d")
 
# Creating plot
a = ax.scatter3D(theta_Nm, mass_Nm, alpha_Nm, cmap = "jet")
#(a, label="NLL")
fig.show()
#%%
"""
Newton 2 - Modified Newton method
8273 [0.70914093 0.00274259 1.26955472]

[0.7091409284261814, -0.012595020654195266, 0.012672441410746083]
[0.0027425878787017965, -3.8022592451681866e-05, 3.810087934024483e-05]
[1.2695547158890406, 0.0010733264400983877, 0.0010733264399493958]
"""
#%%
print(CP1_tools.Parabolic_error_3D(x_minm[0] - 0.1, x_minm[0],x_minm[0],x_minm[0] + 0.1,x_minm[0],x_minm[1],x_minm[2], "theta"))
print(CP1_tools.Parabolic_error_3D(x_minm[1] - 2e-4, x_minm[1],x_minm[1],x_minm[1] + 2e-4,x_minm[0],x_minm[1],x_minm[2], "mass"))
print(CP1_tools.Parabolic_error_3D(x_minm[2] - 0.1, x_minm[2],x_minm[2],x_minm[2] + 0.1,x_minm[2],x_minm[1],x_minm[2], "alpha"))
#%%
NLL_Nm = [CP1_tools.NLL_3D(theta_Nm[i], mass_Nm[i], alpha_Nm[i]) for i in range(len(theta_Nm))]

#%%
fig, axs = plt.subplots(3, sharex = True)
plt.subplots_adjust(hspace=0.1, top = 1.3)

axs[0].plot([0, len(x_minGm)],[x_minG[2], x_minG[2]], label = "$\u03B1 \pm \u0394 \u03B1$", color = "orange")
axs[0].plot(alpha_QN, label = "Quasi Newton", color = "brown")
#axs[0].plot(alpha_G, '--',label = "Gradient", color = "green")
axs[0].plot(alpha_Gm, label = "Gradient with Momentum", color = "green")
axs[0].plot(alpha_N,'--' ,label = "Newton", color = "red")
#plt.plot([0,0], [1,1.2], color = "red") 
axs[0].plot(alpha_Nm, label = "Modified Newton", color = "red")#im adding this because its the initial guesses of the newton method that wasn't added into my array intially
axs[0].plot([0,0], [1,1.2], color = "red")
axs[0].fill_between([0,10e3], [x_QN[2], x_QN[2]], [x_min[2], x_min[2]], color = "orange", alpha = "0.5")
axs[0].grid()
axs[0].set_ylim([0.95,1.3])
axs[0].set_ylabel("$\u03B1$")#'$\u0394 m^{2}_{23}$'

axs[1].plot([0, len(x_minGm)],[x_minG[1], x_minG[1]], label = "$x^{i}_{min} \pm \u03B4 x^{i}_{min}$", color = "orange") #"$\u0394 m^{2}_{23} \pm \u03B4 m^{2}_{23}$"
axs[1].plot(mass_QN, label = "Quasi Newton", color = "brown")
#axs[1].plot(mass_G, '--',label = "Gradient", color = "green")
axs[1].plot(mass_Gm, label = "Gradient with Momentum", color = "green")
axs[1].plot(mass_N,'--' ,label = "Newton", color = "red")
axs[1].plot(mass_Nm, label = "Modified Newton", color = "red")
axs[1].plot([0,0], [0.002,0.0022], color = "green") #adding initial value of gradient

axs[1].fill_between([0,10e3], [x_QN[1], x_QN[1]], [x_min[1], x_min[1]], color = "orange", alpha = "0.7")
axs[1].legend(loc="center right")
axs[1].grid()
#plt.ylim([0.0022,0.00278])
#axs[1].xlabel("Iteration")
axs[1].set_ylabel('$\u0394 m^{2}_{23}$')

axs[2].plot([0, len(theta_Gm)],[x_minG[0], x_minG[0]], label = "$\u03F4_{23} \pm \u0394 \u03F4_{23}$", color = "orange")
axs[2].plot(theta_QN, label = "Quasi Newton", color = "brown")
#axs[2].plot(theta_G, '--',label = "Gradient", color = "green")
axs[2].plot(theta_Gm, label = "Gradient with Momentum", color = "green")
axs[2].plot(theta_N,'--' ,label = "Newton", color = "red")
axs[2].plot(theta_Nm, label = "Modified Newton", color = "red")

#plt.plot([0,0], [0.5,0.6], color = "red") #again - this is the first guess which is added in now
axs[2].fill_between([0,10e3], [x_QN[0], x_QN[0]], [x_min[0], x_min[0]], color = "orange", alpha = "0.7")
#axs[2].legend()
axs[2].grid()
#plt.ylim([0.00248,0.00276])
axs[2].set_xlabel("Iteration")
axs[2].set_ylabel('$\u03F4_{23}$')
#plt.xlim([0,len(theta_G)])


#%%
#plt.plot(theta_all, mass_all)
from mpl_toolkits import mplot3d
fig = plt.figure()
ax = plt.axes(projection='3d')

plt.rcParams.update( \
     {'axes.labelsize': 7,
      'font.size': 8,
      #'path.sketch': True,
      'legend.fancybox': True,
       'xtick.labelsize': 7,
       'ytick.labelsize': 7,
       'xtick.major.bottom': True,
       'xtick.major.pad': 1,
       'xtick.major.size': 1,
        })

n = 9
n2 = 17
#c = ax.scatter3D(theta_N[n2:], mass_N[n2:], alpha_N[n2:], label = "Newton", c = NLL_N[n2:], cmap = "cubehelix" ) 
d = ax.scatter3D(theta_Nm, mass_Nm, alpha_Nm, label = "Modified Newton",  c = NLL_Nm,cmap = "cubehelix") 
a = ax.scatter3D(theta_QN, mass_QN, alpha_QN, label = "Quasi Newton", c = NLL_QN, cmap = "hsv") #range(len(x3))
#b = ax.scatter3D(theta_G, mass_G, alpha_G, label = "Gradient") #cmap = "winter", c = NLL_grad,
e = ax.scatter3D(theta_Gm[n:], mass_Gm[n:], alpha_Gm[n:], label = "Gradient")#, cmap = "winter", c = NLL_grad_m[n:])
ax.legend()
#fig.colorbar(a, shrink=1, aspect=20, label = "$\it{NLL}$")
ax.set_xlabel('$\u03F4_{23}$', labelpad=7, fontsize = 8)
ax.set_ylabel('$\u0394 m^{2}_{23}$', labelpad=7, fontsize = 8)
ax.set_zlabel("$\u03B1$", labelpad=0, fontsize = 9)
ax.set_ylim(0.002,0.0028)
ax.set_xlim(0.46,0.7)
#ax.set_zlim(0.9,1.28)
ax.dist = 13
ax.view_init(30, 45)
#ax.view_init(30, 150)

#%% - calculating the last Hessian inverse estimate
#x = [np.mean([x_minm[i], x_minGm[i], x_QN[i]]) for i in  range(len(x_min))]
#std = [0.0126, 3.8e-5, 1.1e-1]

x = [0.7086162798065545, 0.0027426224378992777, 1.2710870066068625]
d_theta, d_mass, d_alpha = [1e-4, 1e-6, 1e-3]
y_tt = CP1_tools.FD_tt_3D(x[0], x[1], x[2], d_theta)
y_mm = CP1_tools.FD_mm_3D(x[0], x[1], x[2], d_mass)
y_aa = CP1_tools.FD_aa_3D(x[0], x[1], x[2], d_alpha)
y_tm = CP1_tools.FD_tm_3D(x[0], x[1], x[2], d_theta, d_mass) #x_n[0], x_n[1], x_n[2]
y_ta = CP1_tools.FD_ta_3D(x[0], x[1], x[2], d_theta, d_alpha)
y_ma = CP1_tools.FD_ma_3D(x[0], x[1], x[2], d_mass, d_alpha)

H = np.zeros((3,3)) 
H[0,0] = y_tt
H[0,1] = H[1,0] = y_tm
H[0,2] = H[2,0] = y_ta
H[1,2] = H[2,1] = y_ma
H[1,1] = y_mm
H[2,2] = y_aa

H_inv = np.linalg.inv(H) #making sure thats + definite
std = np.sqrt([H_inv[0,0], H_inv[1,1], H_inv[2,2]])
print(std)
print(H_inv)
print(CP1_tools.Positive_def(H_inv))
print(H_inv[0,1]/(std[0]*std[1]))
print(H_inv[1,2]/(std[1]*std[2]))
print(H_inv[0,2]/(std[0]*std[2]))
"""
[[1.76802179e-04 4.64266186e-08 2.34059554e-04]
 [4.64266186e-08 1.46224696e-09 7.79510213e-08]
 [2.34059554e-04 7.79510213e-08 3.39782836e-03]]
"""

#%% - Simulated annealing
T = [10,1]
dT = 1
N = 6000
x_0 = [0.4,1e-3,5]
x_norm = [0.1, 1e-3, 1]
x_min, E_final, x1_all, x2_all, x3_all, E_all, T_all  = CP1_tools.Simulated_annealing(CP1_tools.NLL_3D, x_0, N, dT, T, x_norm)
print('Done!')
#%%
print(x_min)
print(E_final)
#[8.632860866561325, 2.745482843308038, 1.2664744643718835] corresponds to NLL = 49.92435144541689
#[0.70911548 0.00274265 1.27152553] to  49.91285582751373 #if to T = 1:
#%%
plt.plot(x1_all,"-", markersize=1, label ="$\u03F4_{23}$")
plt.plot(x2_all,"-", markersize=1, label ="$\u0394 m^{2}_{23}$")
plt.plot(x3_all,"-", markersize=1,  label = "$\u03B1$")
plt.grid()
plt.legend()
#plt.plot(arrays[3])
plt.xlabel('Iteration Number')
plt.ylabel('Normalised variables')
#plt.ylim([0,4])
#plt.xlim([3000,5000])
plt.show()
#%%
T = [1,0]
dT = 0.1
N = 6000
x_norm = [0.1, 1e-3, 1]
x_min2, E_final2, x1_all2, x2_all2, x3_all2, E_all2, T_all2  = CP1_tools.Simulated_annealing(CP1_tools.NLL_3D, x_min, N, dT, T, x_norm)
#%%
plt.plot(x1_all2,"-", markersize=1, label ="$\u03F4_{23}$")
plt.plot(x2_all2,"-", markersize=1, label ="$\u0394 m^{2}_{23}$")
plt.plot(x3_all2,"-", markersize=1,  label = "$\u03B1$")
plt.grid()
plt.legend()
#plt.plot(arrays[3])
plt.xlabel('Iteration Number')
plt.ylabel('Normalised variables')
#plt.ylim([0.5,2])
#plt.xlim([3000,5000])
plt.show()

#%%
print(x_min2)
#[0.70911548 0.00274265 1.27152553] or [0.86259741 0.00274728 1.2716223]
#%%
print(CP1_tools.NLL_3D(0.70911548, 0.00274265, 1.27152553)) #49.91285555768569
print(CP1_tools.NLL_3D(0.86259741, 0.00274728, 1.2716223)) #49.92435144541689

#%%
x3 = np.array(x3_all + x3_all2)
x1 = np.array(x1_all + x1_all2)
x2 = np.array(x2_all + x2_all2)
E = np.array(E_all + E_all2)
T = np.array(T_all + T_all2)

#%%
plt.plot(x3,"-", markersize=1,  label = "$\u03B1$")
plt.plot(x1,"-", markersize=1, label ="$\u03F4_{23}x10^{-1}$")
plt.plot(x2,"-", markersize=1, label ="$\u0394 m^{2}_{23}x10^{-3}$")


plt.legend(loc=2)
#plt.plot(arrays[3])
plt.xlabel('Iteration Number')
plt.ylabel('Normalised variables')
plt.grid()
#plt.ylim([0.5,2])
#plt.xlim([3000,5000])

plt.show()
#%%
print(np.std(x1[-200:])) #0.06741107137753623e-1
print(np.std(x2[-200:])) #0.019086443569718885e-3
print(np.std(x3[-200:])) #0.02897809943001538
#%%
def prob(dE,T):
    return np.exp(-dE/T)

#dE = np.linspace(0,20, 100)
#T = np.concatenate(np.concatenate(np.concatenate(np.concatenate(np.concatenate(np.ones(1300-1)*10,np.ones(1300-1)*9,np.ones(1300-1)*8),np.ones(1300-1)*7,np.ones(900-1)*6),np.ones(800)*5,np.ones(700)*4),np.ones(600)*3,np.ones(400)*2),np.ones(300)*1,np.ones((len(E)-8300))*0)
color = ["#4B0082", "#8A2BE2","#DC143C","#FF3030", "#FF7D40", "#FFD700", "#FFEC8B", "#87CEFA", "#6495ED", "#1874CD", "#27408B"]
print(T)
#%%
fig, axs = plt.subplots(2)

plt.subplots_adjust(hspace=0.4, top = 1.3)

dE = [E[i] - E_final for i in range(0,len(E))]
#print(dE)
print(len(dE))
print(len(T))
prob_T = [prob(dE[i], T[i]) for i in range(len(E))]
temp = [10,9,8,7,6,5,4,3,2,1] 
#for i in range(len(T)):
#plt.plot(dE, prob_T, 'x')
axs[0].plot(dE[0:1300],prob_T[0:1300], '.', color = "#4B0082", label = "$T={}$".format(temp[0])) 
axs[0].plot(dE[1300:2600],prob_T[1300:2600], '.', color ="#8A2BE2", label = "$T={}$".format(temp[1]))
axs[0].plot(dE[2600:3600],prob_T[2600:3600], '.', color = "#DC143C", label = "$T={}$".format(temp[2]))
axs[0].plot(dE[3600:4600],prob_T[3600:4600], '.',color = "#FF3030", label = "$T={}$".format(temp[3]))
axs[0].plot(dE[4600:5500],prob_T[4600:5500],  '.',color = "#FF7D40", label = "$T={}$".format(temp[4]))
axs[0].plot(dE[5500:6300],prob_T[5500:6300],  '.',color = "#FFD700", label = "$T={}$".format(temp[5]))
axs[0].plot(dE[6300:7000],prob_T[6300:7000],  '.',color = "#FFEC8B", label = "$T={}$".format(temp[6]))
axs[0].plot(dE[7000:7600],prob_T[7000:7600],  '.',color = "#87CEFA", label = "$T={}$".format(temp[7]))
axs[0].plot(dE[7600:8000],prob_T[7600:8000],  '.',color = "#6495ED", label = "$T={}$".format(temp[8]))
axs[0].plot(dE[8000:8300],prob_T[8000:8300],  '.',color = "#1874CD", label = "$T={}$".format(temp[9]))
n=int((len(dE)-8300)/10)
axs[0].plot(dE[8300:8300 + n*1],prob_T[8300:8300 + n*1],  '.',color = "#27408B", label = "$T=1->0$")
for i in range(1,11):
    axs[0].plot(dE[8300:8300 + n*i],prob_T[8300:8300 + n*i], '.', color = "#27408B")

fig.legend(loc="center right")
#axs.legend(loc=1)
axs[0].set_xlim([-2,100])
#plt.grid(b=True, which='major', color='#666666', linestyle='-')
#axs[0].minorticks_on()
#plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
#axs[0].legend()
axs[0].set_ylabel("Probability")
axs[0].set_xlabel('$\u0394 E$', fontsize=9)

#plt.plot(E)
axs[1].plot(range(0,1300),E[0:1300], color = "#4B0082", label = "$T={}$".format(temp[0])) #
axs[1].plot(range(1300,2600),E[1300:2600], color ="#8A2BE2", label = "$T={}$".format(temp[1]))
axs[1].plot(range(2600,3600),E[2600:3600], color = "#DC143C", label = "$T={}$".format(temp[2]))
axs[1].plot(range(3600,4600),E[3600:4600],color = "#FF3030", label = "$T={}$".format(temp[3]))
axs[1].plot(range(4600,5500),E[4600:5500], color = "#FF7D40", label = "$T={}$".format(temp[4]))
axs[1].plot(range(5500,6300),E[5500:6300], color = "#FFD700", label = "$T={}$".format(temp[5]))
axs[1].plot(range(6300,7000),E[6300:7000], color = "#FFEC8B", label = "$T={}$".format(temp[6]))
axs[1].plot(range(7000,7600),E[7000:7600], color = "#87CEFA", label = "$T={}$".format(temp[7]))
axs[1].plot(range(7600,8000),E[7600:8000], color = "#6495ED", label = "$T={}$".format(temp[8]))
axs[1].plot(range(8000,8300),E[8000:8300], color = "#1874CD", label = "$T={}$".format(temp[9]))
n=int((len(E)-8300)/10)
axs[1].plot(range(8300,8300 + n*1),E[8300:8300 + n*1], color = "#27408B", label = "$T=1->0$")
for i in range(1,11):
    axs[1].plot(range(8300,8300 + n*i),E[8300:8300 + n*i], color = "#27408B")#, color = colours[i])
#plt.plot(T/max(T), label = "Temperature")
axs[1].set_ylim([45,175])
#plt.grid()
axs[1].set_xlabel('Iteration Number', fontsize=9)
axs[1].set_ylabel('Energy', fontsize=9)
#%%


#%%
fig = plt.figure()
ax = plt.axes(projection='3d')

plt.rcParams.update( \
     {'axes.labelsize': 8,
      'font.size': 8,
       'xtick.labelsize': 8,
       'ytick.labelsize': 8,
       #'xtick.major.bottom': True,
       'xtick.major.pad': 1,
       'xtick.major.size': 8,
        })

    
a = ax.scatter3D(x1 * x_norm[0], x2, x3 * x_norm[2], c = T, cmap = "nipy_spectral") #range(len(x3))
fig.colorbar(a, shrink=1, aspect=20, label = "Temperature")
ax.set_xlabel('$\u03F4_{23}$')
ax.set_ylabel('$\u0394 m^{2}_{23} x 10^{-3}$')
ax.set_zlabel("$\u03B1$")
#ax.set_xlim(0, 1.6); ax.set_ylim(0, 0.01)#; ax.set_zlim(0, 15000);
ax.dist = 10
ax.set_ylim(1.8,3)


#%%

theta_mean = 0.71049521 #this is the value of x_min2[0] #0.85945158 
theta_std = 0.06741107137753623e-1  #np.std(x1[-200:])
mass_mean = 0.00275319 #x_min2[1] #0.00275319 
mass_std = 0.019086443569718885e-3 #np.std(x2[-200:])
alpha_mean = 1.28557257 #x_min2[2] #1.28557257
alpha_std = 0.02897809943001538  #np.std(x3[-200:])
#%%
theta_sphere = []
mass_sphere = []
alpha_sphere = []
NLL_min = CP1_tools.NLL_3D(theta_mean, mass_mean, alpha_mean)
for i in range(300000):
    print(i)
    theta_new = np.random.normal(theta_mean, theta_std)
    mass_new =  np.random.normal(mass_mean, mass_std)
    alpha_new = np.random.normal(alpha_mean, alpha_std)
    
    NLL_comp = CP1_tools.NLL_3D(theta_new, mass_new, alpha_new) - (NLL_min + 0.5)
    
    if abs(NLL_comp) < 0.01:
        theta_sphere.append(theta_new)
        mass_sphere.append(mass_new)
        alpha_sphere.append(alpha_new)
        print("yes")

#%%
mass_sphere = np.array(mass_sphere)
theta_sphere = np.array(theta_sphere)
alpha_sphere = np.array(alpha_sphere)
#%%
NLL_tma = [CP1_tools.NLL_3D(theta_sphere[i], mass_sphere[i], alpha_sphere[i]) for i in range(len(theta_sphere))]
#%%
NLL_tma -= (NLL_min + 0.5)
#%%
from mpl_toolkits import mplot3d

fig = plt.figure()
ax = plt.axes(projection='3d')

plt.rcParams.update( \
     {'axes.labelsize': 8,
      'font.size': 7,
       'xtick.labelsize': 7,
       'ytick.labelsize': 7,
       #'xtick.major.bottom': True,
       'xtick.major.pad': 0.001,
       'xtick.major.size': 6,
        })

    
a = ax.scatter3D(theta_sphere, mass_sphere * 10**3, alpha_sphere, c = NLL_tma, cmap = "nipy_spectral") #range(len(x3))
fig.colorbar(a, shrink=1, aspect=20, label = "NLL")
ax.set_xlabel('$\u03F4_{23}$')
ax.set_ylabel('$\u0394 m^{2}_{23} x 10^{-3}$')
ax.set_zlabel("$\u03B1$")
#ax.set_xlim(0, 1.6); ax.set_ylim(0, 0.01)#; ax.set_zlim(0, 15000);
ax.plot(theta_sphere, mass_sphere* 10**3, 'grey', zdir='z', zs=1.21, alpha = 0.5)
ax.plot(theta_sphere,alpha_sphere, 'grey', zdir='y', zs= 2.69, alpha = 0.5)#zs= 2.79, alpha = 0.5)
ax.plot(mass_sphere* 10**3, alpha_sphere, 'grey', zdir='x', zs= 0.83, alpha=0.5)#zs= 0.69, alpha = 0.5)
ax.set_ylim(2.69,2.79)
ax.set_xlim(0.83,0.88)#ax.set_xlim(0.69,0.73)
#ax.set_zlim([1.21, 1.33])

ax.view_init(30, 30)
ax.dist = 11
#ax.set_yticklabels(lva='center', ha='right',fontsize=3)
#%%
print(max(theta_sphere))
#%%
alpha_min = alpha_mean #alpha_sphere[np.argmin(theta_sphere)]
alpha_left = min(alpha_sphere)
alpha_right = max(alpha_sphere)
alpha_err_minus = alpha_left - alpha_min
alpha_err_plus = alpha_right - alpha_min
print(alpha_min, alpha_err_plus, alpha_err_minus)

mass_min = mass_mean #mass_sphere[np.argmin(theta_sphere)]
mass_left = min(mass_sphere)
mass_right = max(mass_sphere)
mass_err_minus = mass_left - mass_min
mass_err_plus = mass_right - mass_min 
print(mass_min*1e3, mass_err_plus*1e3, mass_err_minus*1e3, "e-3")

theta_min = theta_mean #theta_sphere[np.argmin(mass_sphere)]
theta_left = min(theta_sphere)
theta_right = max(theta_sphere)
theta_err_minus = theta_left - theta_min
theta_err_plus = theta_right - theta_min
print(theta_min, theta_err_plus, theta_err_minus)
"""
The mean we are not interested in, we just take the uncertaties
mass = 0.04464870199318103 -0.037314503655213986 e-3
theta = 0.014866063161127374 -0.013704673392424649
alpha = 0.08087247159003352 -0.044703208916849535

 0.04781531388035365 -0.07791284369823215
 0.030535448013282226 -0.05139976742573943 e-3
 0.016456360621944666 -0.012114538575564215
"""






