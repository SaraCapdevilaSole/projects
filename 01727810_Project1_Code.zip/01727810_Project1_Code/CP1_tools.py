#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Functions
we use convergence of dx=1e-6 for inbuilt functions (such as secant)
we use convergence of dx=1e-5 for minimisation methods
we use alpha_step = 1e-6
h = 1e-3
"""
import numpy as np
import matplotlib.pyplot as plt

def open_file(data_type): #either: data to fit or unoscillated flux
    if data_type == "Data to Fit":
        filename = '/Users/saracapdevilasole/OneDrive - Imperial College London/Year3/CP/Project/CP1_Data_to_Fit.txt'
    else:
        filename = '/Users/saracapdevilasole/OneDrive - Imperial College London/Year3/CP/Project/CP1_Unoscillated_Flux.txt'
    
    with open(filename) as file:
        lines = file.readlines()
        lines = [line.rstrip() for line in lines]
    data_arr = []
    for l in lines:
        data_arr.append(float(l))
    return np.array(data_arr)

def oscillation_prob(theta_23, dm_23_squ, L, E):
    """
    Parameters
    ----------
    theta_23 : float in rads
        The mixing angle: Determines the amplitude of the neutrino oscillation probability
    dm_23_squ : float in (eV)^2
        Difference between the squared masses of the two neutrinos, which determines the frequency of the oscillations
    L : Float in Km
        Length travelled by muon neutrino
    E: Array in GeV
       Energy of muon neutrino
    Returns: ‘survival probability’ of a muon neutrino 
    -------
    None.

    """
    return 1 - np.sin(2*theta_23)**2 * np.sin(1.267 * dm_23_squ * L / E)**2

def Oscillated_converter(P_mu, Unoscillated_events):
    return P_mu * Unoscillated_events

def plot_event(x, y, x_label, y_label, graph_label):
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.plot(x,y,label = graph_label)
    plt.legend()
    plt.grid(b=True, which='major', color='#666666', linestyle='-')
    plt.minorticks_on()
    plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)

def NLL(theta_23, dm_23_squ, L, E):

    """
    Parameters
    ----------
    theta_23, dm_23_squ (and L:fixed, E: bins) : Array
        Paramters of (simulated + oscillated) event rate prediction.

    Returns
    -------
    Float
        Negative log likelihood
    """
    #dm_23_squ = np.full(len(E), dm_23_squ)
    #L = np.full(len(E), L)

    P_mu = []
    for E_i in E:
        P_mu.append(oscillation_prob(theta_23, dm_23_squ, L, E_i))
    
    Unoscillated_lambda_N = open_file("Unoscillated Events")
    lambda_N = Oscillated_converter(P_mu, Unoscillated_lambda_N)
    
    m_N = open_file("Data to Fit") #Data (observed number of neutrinos in bin i)
    
    #print(lambda_N - m_N + m_N * np.log(m_N / lambda_N))
    return np.nansum(lambda_N - m_N + m_N * np.log(m_N / lambda_N))
 
def Lagrange_x3(x, y):
    x_3 = 1/2 * ((x[2]**2 - x[1]**2) * y[0] + (x[0]**2 - x[2]**2) * y[1] + (x[1]**2 - x[0]**2) * y[2]) / ((x[2] - x[1]) * y[0] + (x[0] - x[2]) * y[1] + (x[1] - x[0]) * y[2])
    dd = 2 * (y[0] / ((x[0] - x[1]) * (x[0] - x[2])) + y[1] / ((x[1] - x[0]) * (x[1] - x[2])) + y[2] / ((x[2] - x[0]) * (x[2] - x[1])) )
    x_err = (dd)**(-0.5)
    return x_3, x_err
       
def NLL_function_err(theta_23, dm_23_squ, theta_min, mass_min, L, E):
    """
    Function to be used to find roots to and hence approximate the 
    error of theta and mass when NLL increases by 0.5 from mininum.
    """
    NLL_min = NLL(theta_min, mass_min, L, E)
    return NLL(theta_23, dm_23_squ, L, E) - (NLL_min + 0.5)
    
def Secant_theta(a, b, theta_min, mass_min, L, E, f = NLL_function_err): #a = 1st guess for theta, b = second guess for theta
    """
    Root finding algorithm - use for theta
    [a,b] is the range in which we want to find the root in
    """
    x_i = a 
    x_im1 = b
    
    dx = abs(x_i - x_im1)

    i = 0
    while dx > 1e-6:
        i += 1
        #print(i)

        f_x_i = f(x_i, mass_min, theta_min, mass_min, L, E)
        f_x_im1 = f(x_im1, mass_min, theta_min, mass_min, L, E)
        
        x_ip1 = x_i - f_x_i*(x_i - x_im1)/(f_x_i - f_x_im1)
        #f_x_ip1 = f(x_ip1, mass_min, theta_min, mass_min, L, E)
        dx = abs(x_ip1 - x_i)
        #print(x_i)
        x_im1 = x_i
        x_i = x_ip1
    return x_i

def Secant_mass(a, b, theta_min, mass_min, L, E, f = NLL_function_err): #a = 1st guess for theta, b = second guess for theta
    """
    Root finding algorithm - use for mass
    """
    x_i = a
    x_im1 = b #x_imp1 must be < x_i
    
    dx = abs(x_i - x_im1)

    i = 0
    while dx > 1e-6:
        i += 1
        print(i)
        f_x_i = f(theta_min, x_i, theta_min, mass_min, L, E)
        f_x_im1 = f(theta_min, x_im1, theta_min, mass_min, L, E)
        
        x_ip1 = x_i - f_x_i*(x_i - x_im1)/(f_x_i - f_x_im1)
        #f_x_ip1 = f(theta_min, x_ip1, theta_min, mass_min, L, E)
        dx = abs(x_ip1 - x_i)
    
        x_im1 = x_i
        x_i = x_ip1
        
    return x_i

def Parabolic_error_theta(a1, b1, a2, b2, theta_min, mass_min, L, E, f = NLL_function_err):
    x_root1 = Secant_theta(a1, b1, theta_min, mass_min, L, E)
    x_root2 = Secant_theta(a2, b2, theta_min, mass_min, L, E)
    
    #first theta root
    error_minus = x_root1 - theta_min
    error_plus = x_root2 - theta_min
    
    return [theta_min, error_minus, error_plus]

def Parabolic_error_mass(a1, b1, a2, b2, theta_min, mass_min, L, E, f = NLL_function_err):
    x_root1 = Secant_mass(a1, b1, theta_min, mass_min, L, E)
    x_root2 = Secant_mass(a2, b2, theta_min, mass_min, L, E)
    
    #first mass root
    error_minus = x_root1 - mass_min
    error_plus = x_root2 - mass_min
    
    return [mass_min, error_minus, error_plus]
    
# - 1D minimisation

def Parabolic_min_theta(x, dm_23_squ, L, E, dx_conv = 1e-5, function = NLL):
    """
    Input is three x coordinates as an Array; (sect. 3.4) these are equivalent to theta_23_i
    """
    dx = 1
    x_all = []
    #dx_conv = 0.001
    while dx > dx_conv:
        y = [function(x_i, dm_23_squ, L, E) for x_i in x]
        x_3, x_err = Lagrange_x3(x, y)
        dx = abs(x[np.argmax(y)] - x_3)
        x[np.argmax(y)] = x_3
        x_all.append(x_3)
    return x_3, x_err, x_all

def Parabolic_min_mass(x, theta_23, L, E, dx_conv = 1e-5, function = NLL):
    """
    Input is three x coordinates as an Array; (sect. 3.4) these are equivalent to dm_23_squ_i
    """
    dx = 1
    x_all = []
    while dx > dx_conv:
        y = [NLL(theta_23, x_i, L, E) for x_i in x]
        x_3, x_err = Lagrange_x3(x, y)
        dx = abs(x[np.argmax(y)] - x_3)
        x[np.argmax(y)] = x_3
        x_all.append(x_3)
    return x_3, x_err, x_all

# - 2D minimisation
    
def Univariate_method(theta_x, mass_x, L, E, function = NLL):
    eps = 1e-1
    mass_x_3 = mass_x[2]
    
    theta_all = []
    mass_all = []
    n = 0
    
    while eps > 1e-5:
        n += 1
        #print(n)
        #do theta first
        theta_x_3, err_th, theta = Parabolic_min_theta(theta_x, mass_x_3, L, E, eps, function = NLL)
        theta_all.append(theta_x_3)
        mass_all.append(mass_x_3)
        
        mass_x_3, err_m, mass = Parabolic_min_mass(mass_x, theta_x_3, L, E, eps, function = NLL)
        theta_all.append(theta_x_3)
        mass_all.append(mass_x_3)
        #print(theta_x_3, mass_x_3)
        eps *= 1e-1
        
    return [theta_all, mass_all]
    
def FD_t(theta, mass, L, E, d_theta): #finite difference scheme for first derivative of theta
    return (NLL(theta + d_theta, mass, L, E) - NLL(theta - d_theta, mass, L, E))/(2*d_theta)

def FD_m(theta, mass, L, E, d_mass): 
    return (NLL(theta, mass + d_mass, L, E) - NLL(theta, mass - d_mass, L, E))/(2*d_mass)
    
def FD_tm(theta, mass, L, E, d_theta, d_mass):
    return (NLL(theta + d_theta, mass + d_mass, L, E) - NLL(theta + d_theta, mass - d_mass, L, E) -  NLL(theta - d_theta, mass + d_mass, L, E) + NLL(theta - d_theta, mass - d_mass, L, E))/(4*d_mass*d_theta)

def FD_tt(theta, mass, L, E, d_theta):
    return (NLL(theta + d_theta, mass, L, E) - 2*NLL(theta, mass, L, E) + NLL(theta - d_theta, mass, L, E))/(d_theta)**2

def FD_mm(theta, mass, L, E, d_mass):
    return (NLL(theta, mass + d_mass, L, E) - 2*NLL(theta, mass, L, E) + NLL(theta, mass - d_mass, L, E))/(d_mass)**2

def gradient_f(theta, mass, L, E, d_theta, d_mass):
    y_t = FD_t(theta, mass, L, E, d_theta)
    y_m = FD_m(theta, mass, L, E, d_mass)
    return [y_t, y_m]

def Gradient_method(theta, mass, L, E, d_theta, d_mass):
    x_n = [theta, mass]
    alpha = 1e-6 #as the value of alpha is smaller theta converges (1e-5), mass doesnt
    dx = [0.1, 0.1]
    n = 0 
    
    theta_all = []
    mass_all = []
    
    x_normalisation = np.array([0.1, 1e-3])#np.array([np.pi/4, 2.4e-3])
    
    x_n /= x_normalisation
    
    while (dx[0] or dx[1]) > 1e-6:
        #print(dx)
        n += 1
        print(n, x_n * x_normalisation)
        grad_f = np.array(gradient_f(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta, d_mass))
        delta_n = - alpha * grad_f
        x_np1 = x_n + delta_n
        
        theta_all.append(x_np1[0] * x_normalisation[0])
        mass_all.append(x_np1[1] * x_normalisation[1])
        dx = abs(delta_n * x_normalisation)
        
        x_n = x_np1
        
    return x_n * x_normalisation, theta_all, mass_all

def Gradient_method2(theta, mass, L, E, d_theta, d_mass, momentum = 0.5):
    x_n = [theta, mass]
    alpha = 1e-6
    dx = [0.01, 0.01]
    n = 0 
    
    theta_all = [theta]
    mass_all = [mass]
    
    x_normalisation = np.array([0.1, 1e-3])#np.array([np.pi/4, 2.4e-3])
    
    x_n /= x_normalisation
    
    change = np.array([0, 0])
    while (dx[0] or dx[1]) > 1e-6:
        #print(dx)
        n += 1
        print(n, x_n * x_normalisation)
        grad_f = np.array(gradient_f(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta, d_mass))
        delta_n = - alpha * grad_f + momentum * change
        x_np1 = x_n + delta_n
        change = np.array(delta_n)
        theta_all.append(x_np1[0] * x_normalisation[0])
        mass_all.append(x_np1[1] * x_normalisation[1])
        dx = abs(delta_n * x_normalisation)
        
        x_n = x_np1
        
    return x_n * x_normalisation, theta_all, mass_all

def Newton(theta, mass, L, E, d_theta, d_mass): #simultaneous_min  #theta and mass are initial estimates of mininum
    
    dx_conv = [1e-5,1e-5]#[1e-4,1e-4]
    dx = [0.1,0.1]
    
    x_n = np.array([theta, mass])
    
    x_normalisation = np.array([0.1, 1e-3])#np.array([np.pi/4, 2.4e-3])
    
    x_n /= x_normalisation
    
    theta_all = []
    mass_all = []
    n = 0
    while dx[0]  > dx_conv[0] or dx[1]  > dx_conv[1]:
        n += 1
        
        y_tt = FD_tt(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta)
        y_tm = FD_tm(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta, d_mass)
        y_mm = FD_mm(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_mass)
    
        grad_f = gradient_f(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta, d_mass)
        #grad_f2 = gradient_f_an(x_n[0], x_n[1], L, E)
        #print(grad_f, grad_f2)
    
        #H_inv = np.zeros((2,2)) #Inverse of Hessian
        #H_inv[0,0] = y_mm
        #H_inv[0,1] = H_inv[1,0] = - y_tm
        #H_inv[1,1] = y_tt
       # detH = (y_tt * y_mm - (y_tm)**2) 
       # H_inv /= detH
        H = np.zeros((2,2)) #Inverse of Hessian
        H[0,0] = y_tt
        H[0,1] = H[1,0] = y_tm
        H[1,1] = y_mm
        
        H_inv = np.linalg.inv(H)
        #print(H)
        #print(H_inv)

        #note, can we use np.dot?
        x_np1 = x_n - np.matmul(H_inv, grad_f)
        #print(H_inv)
        dx = abs(x_np1 - x_n)
        #print(dx)
        print(n, x_np1 * x_normalisation)
        
        theta_all.append(x_np1[0] * x_normalisation[0])
        mass_all.append(x_np1[1] * x_normalisation[1])
        
        x_n = x_np1
    
    return x_n * x_normalisation, theta_all, mass_all

def Newton_2(theta, mass, L, E, d_theta, d_mass): #simultaneous_min  #theta and mass are initial estimates of mininum
    
    dx_conv = [1e-5,1e-5]
    dx = [0.1,0.1]
    
    x_n = np.array([theta, mass])
    
    x_normalisation = np.array([0.1, 1e-3])#np.array([np.pi/4, 2.4e-3])
    
    x_n /= x_normalisation
    
    theta_all = []
    mass_all = []
    n = 0
    while dx[0]  > dx_conv[0] or dx[1]  > dx_conv[1]:
        n += 1
        
        y_tt = FD_tt(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta)
        y_tm = FD_tm(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta, d_mass)
        y_mm = FD_mm(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_mass)
    
        y_t, y_m = gradient_f(x_n[0] * x_normalisation[0], x_n[1] * x_normalisation[1], L, E, d_theta, d_mass)
        
        grad_f = [y_t, y_m]
        
        H = np.zeros((2,2)) #Inverse of Hessian
        H[0,0] = abs(y_tt)
        H[0,1] = H[1,0] = abs(y_tm)
        H[1,1] = abs(y_mm)
        
        for i in range(2):
            for j in range(2):
                if j == i:
                    continue
                else:
                    if grad_f[i] > 0:
                        H[i,j] *= -1
                    elif grad_f[i] < 0:
                        H[i,j] *= 1
        
        H_inv = np.linalg.inv(H)
        print(Positive_def(H_inv))
        
        #print(H)
        #print(H_inv)

        #note, can we use np.dot?
        x_np1 = x_n - np.matmul(H_inv, grad_f)
        #print(H_inv)
        dx = abs(x_np1 - x_n)
        #print(dx)
        print(n, x_np1 * x_normalisation)
        
        theta_all.append(x_np1[0] * x_normalisation[0])
        mass_all.append(x_np1[1] * x_normalisation[1])
        
        x_n = x_np1
    
    return x_n * x_normalisation, theta_all, mass_all

    
def Newton_Quasi(theta, mass, L, E, d_theta, d_mass): #scipy.optimize.minimize(method=‘BFGS')
    x_n = [theta, mass]
    G_n = np.identity(2) #first iteration of inverse hessian guess
    #B_k = np.identity(2)
    alpha = 1e-6
    delta_n = [0.1, 0.1]
    print(delta_n)
    
    x_norm = np.array([0.1, 1e-3])#np.array([np.pi/4, 2.4e-3])
    
    theta_all = []
    mass_all = []
    
    n = 1
    while abs(delta_n[0]) > 1e-5 or abs(delta_n[1]) > 1e-7: #here dx_convergence is not normalised
        n += 1
        #print(G_n)
        y_t, y_m = gradient_f(x_n[0], x_n[1], L, E, d_theta, d_mass)
        
        grad_f = [y_t, y_m]

        delta_n = - alpha * np.matmul(G_n, grad_f)
        #print(delta_n)
        x_n /= x_norm
        
        x_np1 = x_n + delta_n
        
        x_np1 *= x_norm
    
        grad_fp1 = gradient_f(x_np1[0], x_np1[1], L, E, d_theta, d_mass)
    
        gamma_n = np.array([grad_fp1[0] - grad_f[0], grad_fp1[1] - grad_f[1]])
        #print(gamma_n)
        
        G_np1 = G_n + np.outer(delta_n, delta_n) / np.matmul(gamma_n, delta_n) - np.matmul(G_n, np.matmul(np.outer(gamma_n, delta_n), G_n)) / np.matmul(gamma_n, np.matmul(G_n, gamma_n))
        
        G_n = G_np1
        x_n = x_np1

        theta_all.append(x_n[0])
        mass_all.append(x_n[1])
        #print(G_n)
        print(n, x_n)
 
    return x_n, theta_all, mass_all
  
#%% - testing

def Secant_test(a, b, y, f): #a = 1st guess for theta, b = second guess for theta
    """
    Root finding algorithm - use for theta
    [a,b] is the range in which we want to find the root in
    """
    x_i = a 
    x_im1 = b
    
    dx = abs(x_i - x_im1)

    i = 0
    while dx > 1e-6:
        i += 1
        #print(i)

        f_x_i = f(x_i, y)
        f_x_im1 = f(x_im1, y)
        
        x_ip1 = x_i - f_x_i*(x_i - x_im1)/(f_x_i - f_x_im1)
        #f_x_ip1 = f(x_ip1, mass_min, theta_min, mass_min, L, E)
        dx = abs(x_ip1 - x_i)
        #print(x_i)
        x_im1 = x_i
        x_i = x_ip1
    return x_i

def Parabolic_min_test1(function, x1, x2_fixed, dx_conv = 5e-1):
    dx = 1
    x1_all = []
    while dx > dx_conv:
        #print(x)
        y = [function(x1_i, x2_fixed) for x1_i in x1]
        #print(y, dx)
        x1_3, err = Lagrange_x3(x1, y)
        dx = abs(x1[np.argmin(y)] - x1_3)
        x1[np.argmax(y)] = x1_3
        #print(x)
        x1_all.append(x1_3)
    return x1_3, x1_all

def Parabolic_min_test2(function, x1_fixed, x2, dx_conv = 5e-1):
    dx = 1
    x2_all = []
    while dx > dx_conv:
        #print(x)
        y = [function(x1_fixed, x2_i) for x2_i in x2]
        #print(y)
        #print(x2)
        x2_3, err = Lagrange_x3(x2, y)
        dx = abs(x2[np.argmin(y)] - x2_3)
        #print(dx)
        x2[np.argmax(y)] = x2_3
        #print(x)
        x2_all.append(x2_3)
    return x2_3, x2_all

def Univariate_method_test(function, x1, x2, eps_0 = 1e-1):
    eps = 1.1e-1
    x2_3 = 2.5e-3
    n = 0
    
    x1arr = [x1[0]]
    x2arr = [x2[0]]
    
    while eps > eps_0:
        n += 1
        x1_3, x1_arr = Parabolic_min_test1(function, x1, x2_3, eps)
        x2_3, x2_arr = Parabolic_min_test2(function, x1_3, x2, eps)
        x1arr.append(x1_3)
        x2arr.append(x2_3)
        eps *= 1e-1
    return [x1arr, x2arr]
      
def FD_t_test(func, theta, mass, d_theta): #finite difference scheme for first derivative of theta
    return (func(theta + d_theta, mass) - func(theta - d_theta, mass))/(2*d_theta)

def FD_m_test(func, theta, mass, d_mass): 
    return (func(theta, mass + d_mass) - func(theta, mass - d_mass))/(2*d_mass)
    
def FD_tm_test(func, theta, mass, d_theta, d_mass):
    return (func(theta + d_theta, mass + d_mass) - func(theta + d_theta, mass - d_mass) -  func(theta - d_theta, mass + d_mass) + func(theta - d_theta, mass - d_mass))/(4*d_mass*d_theta)

def FD_tt_test(func, theta, mass, d_theta):
    return (func(theta + d_theta, mass) - 2*func(theta, mass) + func(theta - d_theta, mass))/(d_theta)**2

def FD_mm_test(func, theta, mass, d_mass):
    return (func(theta, mass + d_mass) - 2*func(theta, mass) + func(theta, mass - d_mass))/(d_mass)**2

def gradient_f_test(func, theta, mass, d_theta, d_mass):
    y_t = FD_t_test(func, theta, mass, d_theta)
    y_m = FD_m_test(func, theta, mass, d_mass)
    return [y_t, y_m]

def Gradient_method_test(func, theta, mass, d_theta, d_mass):
    x_n = [theta, mass]
    alpha = 1e-6 #as the value of alpha is smaller theta converges (1e-5), mass doesnt
    delta_n = [0.1, 0.1]
    n = 0 
    
    x1_array = []
    x2_array = []
    
    while (abs(delta_n[0]) or abs(delta_n[1])) > 1e-8:
        n += 1
        grad_f = np.array(gradient_f_test(func, x_n[0], x_n[1], d_theta, d_mass))
        delta_n = - alpha * grad_f
        #print(x_n)
        #print(delta_n)
        x_np1 = x_n + delta_n
        x1_array.append(x_np1[0])
        x2_array.append(x_np1[1])
        x_n = x_np1
        
    return x_n, x1_array, x2_array

def Gradient_method2_test(func, theta, mass, d_theta, d_mass, momentum = 0.5):
    x_n = [theta, mass]
    alpha = 1e-6
    dx = [0.01, 0.01]
    n = 0 
    
    theta_all = [theta]
    mass_all = [mass]
    
    change = np.array([0, 0])
    while (dx[0] or dx[1]) > 1e-8:
        #print(dx)
        n += 1
        print(n, x_n)
        grad_f = np.array(gradient_f_test(func, x_n[0], x_n[1], d_theta, d_mass))
        delta_n = - alpha * grad_f + momentum * change
        x_np1 = x_n + delta_n
        change = np.array(delta_n)
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        dx = abs(delta_n)
        
        x_n = x_np1
        
    return x_n, theta_all, mass_all
           
def Newton_test(func, theta, mass, d_theta, d_mass): #simultaneous_min  #theta and mass are initial estimates of mininum
    dx = [0.1,0.1]
    
    x_n = [theta, mass]
    
    theta_all = [theta]
    mass_all = [mass]
    n = 0
    while (abs(dx[0]) or abs(dx[1])) > 1e-7:
        n += 1
        y_tt = FD_tt_test(func, x_n[0], x_n[1], d_theta)
        y_tm = FD_tm_test(func, x_n[0], x_n[1], d_theta, d_mass)
        y_mm = FD_mm_test(func, x_n[0], x_n[1], d_mass)
    
        y_t, y_m = gradient_f_test(func, x_n[0], x_n[1], d_theta, d_mass)
        
        grad_f = [y_t, y_m]
        
        H_inv = np.zeros((2,2)) #Inverse of Hessian
        H_inv[0,0] = y_mm
        H_inv[0,1] = H_inv[1,0] = - y_tm
        H_inv[1,1] = y_tt
        detH = (y_tt * y_mm - (y_tm)**2) 
        H_inv /= detH

        #note, can we use np.dot?
        x_np1 = x_n - np.dot(H_inv, grad_f)
        #print(x_np1)
        dx = abs(x_np1 - x_n)
        #print(dx)
        #print(x_np1)
        
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        
        x_n = x_np1
    
    return x_n, theta_all, mass_all  

        
def Newton2_test(func, theta, mass, d_theta, d_mass):
    dx = [0.1,0.1]
    
    x_n = [theta, mass]
    
    theta_all = [theta]
    mass_all = [mass]
    n = 0
    while (abs(dx[0]) or abs(dx[1])) > 1e-6:
        n += 1
        y_tt = FD_tt_test(func, x_n[0], x_n[1], d_theta)
        y_tm = FD_tm_test(func, x_n[0], x_n[1], d_theta, d_mass)
        y_mm = FD_mm_test(func, x_n[0], x_n[1], d_mass)
    
        y_t, y_m = gradient_f_test(func, x_n[0], x_n[1], d_theta, d_mass)
        
        grad_f = [y_t, y_m]
        
        H = np.zeros((2,2)) #Inverse of Hessian
        H[0,0] = abs(y_tt)
        H[0,1] = H[1,0] = abs(y_tm)
        H[1,1] = abs(y_mm)
        
        for i in range(2):
            for j in range(2):
                if j == i:
                    continue
                else:
                    if grad_f[i] > 0:
                        H[i,j] *= -1
                    elif grad_f[i] < 0:
                        H[i,j] *= 1
        
        H_inv = np.linalg.inv(H)
        print(Positive_def(H_inv))
            
        print(H_inv)
        dx = - np.matmul(H_inv, grad_f)
        #print(x_np1)
        x_np1 = x_n + dx
        dx = abs(x_np1 - x_n)
        #print(dx)
        #print(x_np1)
        
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        
        x_n = x_np1
    
    return x_n, theta_all, mass_all  

def Newton_Quasi_test(func, theta, mass, d_theta, d_mass): #this function is not working
    x_n = [theta, mass]
    G_n = np.identity(2) #first iteration of inverse hessian guess
    alpha = 1e-5 #as the value of alpha is smaller theta converges (1e-5), mass doesnt
    delta_n = [0.1, 0.1]
    #print(delta_n)
    x1_array = []
    x2_array = []
    n = 1
    while (abs(delta_n[0]) or abs(delta_n[1])) > 1e-7:
        n += 1
        #print(G_n)
        y_t, y_m = gradient_f_test(func, x_n[0], x_n[1], d_theta, d_mass)
        
        grad_f = [y_t, y_m]
    
        delta_n = - alpha * np.matmul(G_n, grad_f)
        print(Positive_def(G_n))
        x_np1 = x_n + delta_n
    
        y_tp1, y_mp1 = gradient_f_test(func, x_np1[0], x_np1[1], d_theta, d_mass)
        
        grad_fp1 = [y_tp1, y_mp1]
        
        gamma_n = np.array([grad_fp1[0] - grad_f[0], grad_fp1[1] - grad_f[1]])
        #print(gamma_n)
        
        #G_np1 = G_n + np.outer(delta_n, delta_n) / np.matmul(gamma_n, delta_n) - np.matmul(G_n, np.matmul(np.outer(gamma_n, gamma_n), G_n)) / np.matmul(gamma_n, G_n, gamma_n)
        G_np1 = G_n + np.outer(delta_n, delta_n) / np.matmul(gamma_n, delta_n) - np.matmul(G_n, np.matmul(np.outer(gamma_n, delta_n), G_n)) / np.matmul(gamma_n, np.matmul(G_n, gamma_n))
        
        G_n = G_np1
        x_n = x_np1
        x1_array.append(x_n[0])
        x2_array.append(x_n[1])
        print(x_np1)
    
    return x_n, x1_array, x2_array
     
#%% - 3D
    
def Predict_lambda_i(theta_23, dm_23_squ, alpha):
    L = 295
    E_max = 10 #GeV
    E_min = 0
    N = 200

    dE = (E_max - E_min) / N
    E = np.arange(E_min + dE, E_max + dE, dE)
    
    Unoscillated_lambda_N = open_file("Unoscillated Events")
    
    lambda_new = []
    for i in range(N):
        P_mu = oscillation_prob(theta_23, dm_23_squ, L, E[i])
        lambda_old = Oscillated_converter(P_mu, Unoscillated_lambda_N[i])
        lambda_new.append(lambda_old * alpha * E[i])
    
    return lambda_new

def NLL_3D(theta_23, dm_23_squ, alpha):
   
    lambda_N = Predict_lambda_i(theta_23, dm_23_squ, alpha)
    
    m_N = open_file("Data to Fit") #Data (observed number of neutrinos in bin i)
    
    #print(lambda_N - m_N + m_N * np.log(m_N / lambda_N))
    return np.nansum(lambda_N - m_N + m_N * np.log(m_N / lambda_N))

def FD_t_3D(theta, mass, alpha, d_theta, f = NLL_3D): #finite difference scheme for first derivative of theta
    return (f(theta + d_theta, mass, alpha) - f(theta - d_theta, mass, alpha))/(2*d_theta)

def FD_m_3D(theta, mass, alpha, d_mass, f = NLL_3D): 
    return (f(theta, mass + d_mass, alpha) - f(theta, mass - d_mass, alpha))/(2*d_mass)
 
def FD_a_3D(theta, mass, alpha, d_alpha, f = NLL_3D): 
    return (f(theta, mass, alpha + d_alpha) - f(theta, mass, alpha - d_alpha))/(2*d_alpha)
    
def FD_tm_3D(theta, mass, alpha, d_theta, d_mass, f = NLL_3D):
    return (f(theta + d_theta, mass + d_mass, alpha) - f(theta + d_theta, mass - d_mass, alpha) -  f(theta - d_theta, mass + d_mass, alpha) + f(theta - d_theta, mass - d_mass, alpha))/(4*d_mass*d_theta)

def FD_tt_3D(theta, mass, alpha, d_theta, f = NLL_3D):
    return (f(theta + d_theta, mass, alpha) - 2*f(theta, mass, alpha) + f(theta - d_theta, mass, alpha))/(d_theta)**2

def FD_mm_3D(theta, mass, alpha, d_mass, f = NLL_3D):
    return (f(theta, mass + d_mass, alpha) - 2*f(theta, mass, alpha) + f(theta, mass - d_mass, alpha))/(d_mass)**2

def FD_aa_3D(theta, mass, alpha, d_alpha, f = NLL_3D):
    return (f(theta, mass, alpha + d_alpha) - 2*f(theta, mass, alpha) + f(theta, mass, alpha - d_alpha))/(d_alpha)**2

def FD_ta_3D(theta, mass, alpha, d_theta, d_alpha, f = NLL_3D):
    return (f(theta + d_theta, mass, alpha + d_alpha) - f(theta + d_theta, mass, alpha - d_alpha) -  f(theta - d_theta, mass, alpha + d_alpha) + f(theta - d_theta, mass, alpha - d_alpha))/(4*d_alpha*d_theta)

def FD_ma_3D(theta, mass, alpha, d_mass, d_alpha, f = NLL_3D):
    return (f(theta, mass + d_mass, alpha + d_alpha) - f(theta, mass - d_mass, alpha + d_alpha) -  f(theta, mass + d_mass, alpha - d_alpha) + f(theta, mass - d_mass, alpha - d_alpha))/(4*d_mass*d_alpha)

def gradient_f_3D(theta, mass, alpha, d_theta, d_mass, d_alpha):
    y_t = FD_t_3D(theta, mass, alpha, d_theta)
    y_m = FD_m_3D(theta, mass, alpha, d_mass)
    y_a = FD_a_3D(theta, mass, alpha, d_alpha)
    return [y_t, y_m, y_a]

def Gradient_method_3D(theta, mass, alpha):
    d_theta, d_mass, d_alpha = [1e-4, 1e-6, 1e-3]#[1e-6, 1e-6, 1e-6]
    x_n = [theta, mass, alpha]
    alpha_conv = 1e-6
    dx = [0.1, 0.1, 0.1]
    n = 0 
    
    theta_all = []
    mass_all = []
    alpha_all = []
    
    x_normalisation = np.array([0.1, 1e-3, 1])
    
    while (dx[0] or dx[1] or dx[2]) > 1e-5:#1e-6:
        #print(dx)
        n += 1
        print(n, x_n)
        grad_f = np.array(gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha))
        #print(grad_f)
        x_n /= x_normalisation
        
        delta_n = - alpha_conv * grad_f
        x_np1 = x_n + delta_n
        
        x_np1 *= x_normalisation
        
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        alpha_all.append(x_np1[2])
        
        dx = abs(delta_n)
        
        x_n = x_np1
        
    return x_n, theta_all, mass_all, alpha_all

def Gradient_method2_3D(theta, mass, alpha, momentum = 0.5):
    d_theta, d_mass, d_alpha = [1e-4, 1e-6, 1e-3] #[1e-6, 1e-6, 1e-6]
    x_n = [theta, mass, alpha]
    alpha_conv = 1e-6
    change = np.array([0, 0, 0])
    dx = [0.1, 0.1, 0.1]
    n = 0 
    
    theta_all = []
    mass_all = []
    alpha_all = []
    
    x_normalisation = np.array([0.1, 1e-3, 1])
    
    while (dx[0] or dx[1] or dx[2]) > 1e-5:
        #print(dx)
        n += 1
        print(n, x_n)
        grad_f = np.array(gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha))
        #print(grad_f)
        x_n /= x_normalisation
        
        delta_n = - alpha_conv * grad_f + momentum * change
        change = np.array(delta_n)
        x_np1 = x_n + delta_n
        
        x_np1 *= x_normalisation
        
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        alpha_all.append(x_np1[2])
        
        dx = abs(delta_n)
        
        x_n = x_np1
        
    return x_n, theta_all, mass_all, alpha_all

def Positive_def(x):
    return np.all(np.linalg.eigvals(x) > 0)

def Newton_3D(theta, mass, alpha): 
    
    d_theta, d_mass, d_alpha = [1e-4, 1e-6, 1e-3]
    dx = [0.1, 0.1, 0.1]
    dx_conv = 1e-6
    
    x_n = np.array([theta, mass, alpha])
    
    x_normalisation = np.array([0.1, 1e-3, 1])
    
    theta_all = []
    mass_all = []
    alpha_all = []
    n = 0
    while (dx[0] or dx[1] or dx[2]) > dx_conv:
        n += 1
        
        y_t, y_m, y_a = gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha)
        
        y_tt = FD_tt_3D(x_n[0], x_n[1], x_n[2], d_theta)
        y_mm = FD_mm_3D(x_n[0], x_n[1], x_n[2], d_mass)
        y_aa = FD_aa_3D(x_n[0], x_n[1], x_n[2], d_alpha)
        y_tm = FD_tm_3D(theta, mass, alpha, d_theta, d_mass) #x_n[0], x_n[1], x_n[2]
        y_ta = FD_ta_3D(theta, mass, alpha, d_theta, d_alpha)
        y_ma = FD_ma_3D(theta, mass, alpha, d_mass, d_alpha)
        
        grad_f = gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha)

        x_n /= x_normalisation
    
        H = np.zeros((3,3)) #Inverse of Hessian
        H[0,0] = y_tt
        H[0,1] = H[1,0] = y_tm
        H[0,2] = H[2,0] = y_ta
        H[1,2] = H[2,1] = y_ma
        H[1,1] = y_mm
        H[2,2] = y_aa

        #note, can we use np.matmul and linalg?
            
        H_inv = np.linalg.inv(H)
        print(H_inv)
            
        x_np1 = x_n - np.matmul(H_inv, grad_f)
        
        #print(x_np1)
        dx = abs(x_np1 - x_n) 
        #print(dx)
        x_np1 *= x_normalisation
        #print(H)
        print(n, x_np1)
        
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        alpha_all.append(x_np1[2])
        
        x_n = x_np1
    
    return x_n, theta_all, mass_all, alpha_all   

def Newton2_3D(theta, mass, alpha): 
    
    d_theta, d_mass, d_alpha = [1e-5, 1e-7, 1e-4]
    dx = [0.1, 0.1, 0.1]
    dx_conv = 1e-7
    
    x_n = np.array([theta, mass, alpha])
    
    x_normalisation = np.array([0.1, 1e-3, 1])
    
    theta_all = []
    mass_all = []
    alpha_all = []
    n = 0
    while (dx[0] or dx[1] or dx[2]) > dx_conv:
        n += 1
        
        y_t, y_m, y_a = gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha)
        
        y_tt = FD_tt_3D(x_n[0], x_n[1], x_n[2], d_theta)
        y_mm = FD_mm_3D(x_n[0], x_n[1], x_n[2], d_mass)
        y_aa = FD_aa_3D(x_n[0], x_n[1], x_n[2], d_alpha)
        y_tm = FD_tm_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass) #x_n[0], x_n[1], x_n[2]
        y_ta = FD_ta_3D(x_n[0], x_n[1], x_n[2], d_theta, d_alpha)
        y_ma = FD_ma_3D(x_n[0], x_n[1], x_n[2], d_mass, d_alpha)
        
        grad_f = gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha)
        grad_f = np.array(grad_f)
        x_n /= x_normalisation
    
        H = np.zeros((3,3)) #Inverse of Hessian
        H[0,0] = abs(y_tt)
        H[0,1] = H[1,0] = abs(y_tm)
        H[0,2] = H[2,0] = abs(y_ta)
        H[1,2] = H[2,1] = abs(y_ma)
        H[1,1] = abs(y_mm)
        H[2,2] = abs(y_aa)
        
        for i in range(3):
            for j in range(3):
                if j == i:
                    continue
                else:
                    if grad_f[i] > 0:
                        H[i,j] *= -1
                    elif grad_f[i] < 0:
                        H[i,j] *= 1
        
        H_inv = np.linalg.inv(H)
        print(Positive_def(H_inv))
            
        print(H, H_inv)
        dx = - np.matmul(H_inv, grad_f)
            
        x_np1 = x_n + dx
        
        #print(x_np1)
        dx = abs(x_np1 - x_n) 
        #print(dx)
        x_np1 *= x_normalisation
        #print(H)
        print(n, x_np1)
        
        theta_all.append(x_np1[0])
        mass_all.append(x_np1[1])
        alpha_all.append(x_np1[2])
        
        x_n = x_np1
    
    return x_n, theta_all, mass_all, alpha_all  

  
def Newton_Quasi_3D(theta, mass, alpha): #scipy.optimize.minimize(method=‘BFGS')
    x_n = [theta, mass, alpha]
    d_theta, d_mass, d_alpha = [1e-5, 1e-7, 1e-4]
    G_n = np.identity(3) #first iteration of inverse hessian guess
    #B_k = np.identity(2)
    alpha = 1e-6
    delta_n = [0.1, 0.1, 0.1]
    print(delta_n)
    
    x_norm = np.array([0.1, 1e-3, 1]) #np.array([np.pi/4, 2.4e-3])
    
    theta_all = []
    mass_all = []
    alpha_all = []
    
    n = 1
    while abs(delta_n[0]) > 1e-5 or abs(delta_n[1]) > 1e-7:
        n += 1
        #print(G_n)
        y_t, y_m, y_a = gradient_f_3D(x_n[0], x_n[1], x_n[2], d_theta, d_mass, d_alpha)
        
        grad_f = [y_t, y_m, y_a]

        delta_n = - alpha * np.matmul(G_n, grad_f)
        #print(delta_n)
        x_n /= x_norm
        
        x_np1 = x_n + delta_n
        
        x_np1 *= x_norm
    
        grad_fp1 = gradient_f_3D(x_np1[0], x_np1[1], x_np1[2], d_theta, d_mass, d_alpha)
    
        gamma_n = np.array([grad_fp1[0] - grad_f[0], grad_fp1[1] - grad_f[1], grad_fp1[2] - grad_f[2]])
        #print(gamma_n)
        
        G_np1 = G_n + np.outer(delta_n, delta_n) / np.matmul(gamma_n, delta_n) - np.matmul(G_n, np.matmul(np.outer(gamma_n, delta_n), G_n)) / np.matmul(gamma_n, np.matmul(G_n, gamma_n))
  
        G_n = G_np1
        x_n = x_np1

        theta_all.append(x_n[0])
        mass_all.append(x_n[1])
        alpha_all.append(x_n[2])
        #print(G_n)
        print(n, x_n)
 
    return x_n, theta_all, mass_all, alpha_all


def NLL_function_err_3D(theta_23, dm_23_squ, alpha, theta_min, mass_min, alpha_min):
    """
    Function to be used to find roots to and hence approximate the 
    error of theta and mass when NLL increases by 0.5 from mininum.
    """
    NLL_min = NLL_3D(theta_min, mass_min, alpha_min)
    return NLL_3D(theta_23, dm_23_squ, alpha) - (NLL_min + 0.5)

def Secant_3D(a, b, theta_min, mass_min, alpha_min, type_input, f = NLL_function_err_3D): 
    """
    Root finding algorithm - variable in range [a,b]
    """
    x_i = a
    x_im1 = b #x_imp1 must be < x_i
    
    dx = abs(x_i - x_im1)

    i = 0
    while dx > 1e-6:
        i += 1
        #print(i)
        if type_input == "theta":
            f_x_i = f(x_i, mass_min, alpha_min, theta_min, mass_min, alpha_min)
            f_x_im1 = f(x_im1, mass_min, alpha_min, theta_min, mass_min, alpha_min)
            
        if type_input == "mass":
            f_x_i = f(theta_min, x_i, alpha_min, theta_min, mass_min, alpha_min)
            f_x_im1 = f(theta_min, x_im1, alpha_min, theta_min, mass_min, alpha_min)
            
        if type_input == "alpha":
            f_x_i = f(theta_min, mass_min, x_i, theta_min, mass_min, alpha_min)
            f_x_im1 = f(theta_min, mass_min, x_im1, theta_min, mass_min, alpha_min)
        
        x_ip1 = x_i - f_x_i*(x_i - x_im1)/(f_x_i - f_x_im1)
        #f_x_ip1 = f(theta_min, x_ip1, theta_min, mass_min, L, E)
        dx = abs(x_ip1 - x_i)
    
        x_im1 = x_i
        x_i = x_ip1
        
    return x_i  

def Parabolic_error_3D(a1, b1, a2, b2, theta_min, mass_min, alpha_min, type_input):
    x_root1 = Secant_3D(a1, b1, theta_min, mass_min, alpha_min, type_input)
    x_root2 = Secant_3D(a2, b2, theta_min, mass_min, alpha_min, type_input)
    if type_input == "theta":
        
        error_minus = x_root1 - theta_min
        error_plus = x_root2 - theta_min
    
        return [theta_min, error_minus, error_plus]
    
    if type_input == "mass":  

        error_minus = x_root1 - mass_min
        error_plus = x_root2 - mass_min
    
        return [mass_min, error_minus, error_plus]
    
    if type_input == "alpha":
        
        #first theta root
        error_minus = x_root1 - alpha_min
        error_plus = x_root2 - alpha_min
    
        return [alpha_min, error_minus, error_plus]

# - Global minima: Simulated annealing
        
def Simulated_annealing(function, x_0, N, dT, T, x_norm):
    """
    x_0 = Initial guesses for parameters
    N = number of iterations
    """
    x_0 = np.array(x_0)
    x_norm = np.array(x_norm)
    
    x_0 = np.divide(x_0, x_norm, out=x_0, casting='unsafe')
    
    x_min = x_0
    E_min =  function(x_min[0] * x_norm[0], x_min[1] * x_norm[1], x_min[2] * x_norm[2]) #Initial -> best evaluation of minimum
    x_curr = x_0
    E_1 = E_min
    
    x1_all = []
    x2_all = []
    x3_all = []
    E_all = []
    T_all = []
    
    for t in np.arange(T[0], T[1] - dT, - dT):
        #print(t)
        print(t, x_min, E_min)
        for i in range(N):
            x_cand = [np.random.normal(x_curr[i], 0.2) for i in range(len(x_min))]#x_curr[i] + uniform(-1, 1)*dT/100 for i in range(len(x_min))]
        
            E_2 = function(x_cand[0] * x_norm[0], x_cand[1] * x_norm[1], x_cand[2] * x_norm[2])
            #print(x_cand, E_2)
            #print(x_min, E_min)
            dE = (E_2 - E_1)
            
            if E_2 < E_min:
                #print("E_2 < E_min")
                x_min, E_min = x_cand, E_2  
                x_curr, E_1 = x_cand, E_2 
                x1_all.append(x_cand[0])
                x2_all.append(x_cand[1])
                x3_all.append(x_cand[2])
                T_all.append(t)
                E_all.append(E_2)
                
            elif dE <= 0:
                #print("dE <= 0")
                #x_min, E_min = x_cand, E_2   
                x1_all.append(x_cand[0])
                x2_all.append(x_cand[1])
                x3_all.append(x_cand[2])
                T_all.append(t)
                E_all.append(E_2)
                x_curr, E_1 = x_cand, E_2 
                
            elif dE > 0:
                #print("dE > 0")
                if (np.random.uniform(0,1) < np.exp( - dE / t)):
                    #print("exponent:", np.exp( - dE / t))
                    x_curr, E_1 = x_cand, E_2 
                else:
                    continue
    return [x_min * x_norm, E_min, x1_all, x2_all, x3_all, E_all, T_all]
     













