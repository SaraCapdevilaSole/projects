#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Creating plots for the visualisation of changing parameters
"""

import numpy as np
import matplotlib.pyplot as plt
import CP1_tools

data = CP1_tools.open_file("Data to Fit")
    
E_max = 10 #GeV
E_min = 0
N = 200

dE = (E_max - E_min) / N
E = np.arange(E_min + dE, E_max + dE, dE)


#%% 3.2 - Probability as a function of E (varying theta)
theta_23 = np.array([1/16,1/10,1/8,1/4,1/3,1/2,1]) * np.pi #rads
dm_23_squ = 2.4e-3 #(eV)^2 #as theta increase oscillation increases through a larger range of Energies
L = 295 #Km

E = np.arange(E_min + dE, E_max + dE, dE) #E = np.arange(E_min, E_max, dE) #note: what happens at E=0?
P_mu = np.zeros((len(theta_23), len(E)))
for i in range(len(theta_23)):
    for j in range(len(E)):
        P_mu[i,j] = CP1_tools.oscillation_prob(theta_23[i], dm_23_squ, L, E[j])
#%% 
labels = [16,10,8,4,3,2,1]
colours = ["#edeb00", "#ffae00", "#ff5700", "#1a7100","#8e6100", "blue", "black"]

for i in range(len(theta_23)):
    plt.plot(E, P_mu[i], label = "$\u03B8_{{{}}}=\u03C0/{}$".format(23,labels[i]), color = colours[i])
    CP1_tools.plot_event([], [], "Energy (GeV)", "Survival probability of muon", "")
    plt.legend()
#%% mass variation plots
theta_23 = np.pi/4 #rads
dm_23_squ = [2.4e-3 * 2, 2.4e-3, 2.4e-3*0.5, 2.4e-3 * 0.1] #(eV)^2 #as theta increase oscillation increases through a larger range of Energies
L = 295 #Km

E = np.arange(E_min + dE, E_max + dE, dE) #E = np.arange(E_min, E_max, dE) #note: what happens at E=0?
P_mu = np.zeros((len(dm_23_squ), len(E)))
for i in range(len(dm_23_squ)):
    for j in range(len(E)):
        P_mu[i,j] = CP1_tools.oscillation_prob(theta_23, dm_23_squ[i], L, E[j])
        
#%% 
labels = [2, 1, 0.5, 0.1]
colours = ["#ff5700", "brown", "#1a7100", "blue"]

for i in range(len(dm_23_squ)):
    plt.plot(E, P_mu[i], label = "${} * \u0394 m_{{{}}}^2$".format(labels[i], 23), color = colours[i])
    CP1_tools.plot_event([], [], "Energy (GeV)", "Survival probability of muon", "")
    plt.legend()


#%% - now data

theta_23 = np.pi/4 #rads
dm_23_squ = 2.4e-3 #(eV)^2 #as theta increase oscillation increases through a larger range of Energies
L = 295 #Km

E = np.arange(E_min + dE, E_max + dE, dE) #E = np.arange(E_min, E_max, dE) #note: what happens at E=0?
P_mu = []
for E_i in E:
    P_mu.append(CP1_tools.oscillation_prob(theta_23, dm_23_squ, L, E_i))

Un_Osc_ev = CP1_tools.open_file("Unoscillated Events")

#oscillated event rate prediction: Osc_ev = lambda_i
Osc_ev = CP1_tools.Oscillated_converter(P_mu, Un_Osc_ev) #oscillates events from simulated unoscillated event data * P_mu

#CP1_tools.plot_event(E, Un_Osc_ev, "Energy (GeV)", "Events", "Unoscillated event prediction")
CP1_tools.plot_event([], [], "Energy (GeV)", "Number of events (N)", "")
plt.plot(E, Osc_ev, label = "Oscillated event prediction ($\lambda_i$)", color = "black")


plt.bar(x = E, height = data, width = 0.05, label = "Observed data $(m_i)$", color = "grey")
#plt.plot(E, data, label = "Data $(m_i)$")
plt.legend()
#%%
from mpl_toolkits import mplot3d
theta_23_array = np.linspace(0, np.pi/2, 50)
dm_23_squ_array = np.linspace(0, 0.01, 50)

X, Y = np.meshgrid(theta_23_array, dm_23_squ_array)
Z = np.zeros((len(theta_23_array),len(dm_23_squ_array)))

for i in range(len(theta_23_array)):
    for j in range(len(dm_23_squ_array)):
        Z[i,j] = CP1_tools.NLL(theta_23_array[i], dm_23_squ_array[j], L, E)

#%%
fig = plt.figure()
ax = plt.axes(projection='3d')

plt.rcParams.update( \
     {'axes.labelsize': 8,
      'font.size': 7,
       'xtick.labelsize': 7,
       'ytick.labelsize': 7,
       #'xtick.major.bottom': True,
       'xtick.major.pad': 0.001,
       'xtick.major.size': 6,
        })

#plt.rcParams.update({'font.size': 5})
ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap='pink', edgecolor='none')
                #cmap='viridis', 

ax.set_xlabel('$\u03F4_{23}$')
ax.set_ylabel('$\u0394 m^{2}_{23}$')
ax.set_zlabel('$NLL$')
#ax.set_xlim(0, 1.6); ax.set_ylim(0, 0.01)#; ax.set_zlim(0, 15000);
ax.view_init(30, 50)
ax.dist = 11
#%%
dm_23_squ = np.array([1.1,1.5,1.7,2.3]) * 1e-3#2.4e-3 #(eV)^2

theta_23_array = np.linspace(0, np.pi/2, len(E))
Neg_LL = [[CP1_tools.NLL(theta_23_i, dm_23_squ_i, L, E) for theta_23_i in theta_23_array] for dm_23_squ_i in dm_23_squ]

#%%
x_theta = [0.9,0.8,0.7]
label = ["$\u03F4_{23} = \pi/4$", "", "", ""]

for i in range(len(dm_23_squ)):
    theta_min, theta_err, theta_arr = CP1_tools.Parabolic_min_theta(x_theta, dm_23_squ[i], L, E)
    #theta2_min, theta2_err, theta2_arr = CP1_tools.Parabolic_min_theta(x_theta2, dm_23_squ[i], L, E)
#plt.title("Minimum of $\u03B8_{{{}}} = {:.3f} \pm {:.3f}$ and ${:.3f} \pm {:.3f}$ rads".format(23, theta_min, theta_err, theta2_min, theta2_err))
    CP1_tools.plot_event(theta_23_array, Neg_LL[i] - min(Neg_LL[i]), "$\u03B8_{{{23}}}$", "NLL", label[i]) #, "theta_min = {}".format(theta_min))#, theta2_min))
    plt.ylim([0,800])
#%%
#simultaed annealling:
dm_23_squ_SA = [2.74e-3, 0.04e-3, -0.03e-3] #simulated annealling
theta_23_SA = [0.709, 0.015, -0.014]
alpha_SA = [1.27, 0.08, -0.04]
#%% - Newton
theta_23_N = [0.7091409284261814, -1.32955539e-02, 1.32955539e-02] #1.32955539e-02
dm_23_squ_N = [0.0027425878787017965, -3.82259436e-05, 3.82259436e-05] #3.82259436e-05
alpha_N = [1.2695547158890406, -5.82739293e-02, 5.82739293e-02] #5.82739293e-02
#%% - Quasi Newton
theta_23_QN = [0.7086162798065545, -1.32900408e-02, 1.32900408e-02] #1.32900408e-02
dm_23_squ_QN = [0.0027426224378992777, -3.82452465e-05, 3.82452465e-05] #3.82452465e-05
alpha_QN = [1.2710870066068625, -5.83836181e-02, 5.83836181e-02] #5.83836181e-02
#%% - Gradient with momentum
theta_23_Gm = [0.7089687256421676, -0.012527743705301075, 0.012755656344760724] #1.33045624e-02
dm_23_squ_Gm = [0.002742696120048727, -3.821846658880971e-05, 3.792080871110838e-05] #3.82468602e-05
alpha_Gm = [1.2680851287946742, -0.0010789464926390657, 0.0010789464893266043] #5.82152747e-02
#%% - Gradient method
theta_23_G = [0.7087887640244479, - 0.012, 0.013]
dm_23_squ_G =[ 0.0027426424454960775, - 0.038e-3, 0.0379e-3]
alpha_G = [1.2666449564191815, 0.0010845, -0.0010845]
#%% - Final plot
from scipy import stats
L = 295 #Km

E_max = 10 #GeV
E_min = 0
N = 200
dE = (E_max - E_min) / N
E = np.arange(E_min + dE, E_max + dE, dE)
data = CP1_tools.open_file("Data to Fit")

lambda_initial = CP1_tools.Predict_lambda_i(0.5, 0.002, 1)
chi, p = stats.chisquare(f_obs=data, f_exp=lambda_initial)
print((1 - p)*100)


CP1_tools.plot_event([], [], "Energy (GeV)", "Number of events (N)", "")

lambda_new_SA = CP1_tools.Predict_lambda_i(theta_23_SA[0], dm_23_squ_SA[0], alpha_SA[0])
lambda_new_N = CP1_tools.Predict_lambda_i(theta_23_N[0], dm_23_squ_N[0], alpha_N[0])
lambda_new_QN = CP1_tools.Predict_lambda_i(theta_23_QN[0], dm_23_squ_QN[0], alpha_QN[0])
lambda_new_G = CP1_tools.Predict_lambda_i(theta_23_G[0], dm_23_squ_G[0], alpha_G[0])
lambda_new_Gm = CP1_tools.Predict_lambda_i(theta_23_Gm[0], dm_23_squ_Gm[0], alpha_Gm[0])

y_up = CP1_tools.Predict_lambda_i(theta_23_SA[0] + theta_23_SA[1], dm_23_squ_SA[0] + dm_23_squ_SA[1], alpha_SA[0] + alpha_SA[1])
y_down = CP1_tools.Predict_lambda_i(theta_23_SA[0] + theta_23_SA[2], dm_23_squ_SA[0] + dm_23_squ_SA[2], alpha_SA[0] + alpha_SA[2])

lambda_arr = [lambda_new_SA, lambda_new_N, lambda_new_QN, lambda_new_G, lambda_new_Gm]

colours = ["black", "blue", "#1a7100", "brown", "orange"]
labels = ["Simulated Annealing", "(Mod.) Newton", "Quasi Newton", "Gradient", "Gradient w/ momentum"]
marker = ["x", "--", "-", "."]
for i in range(len(lambda_arr)):
    chi, p_i = stats.chisquare(f_obs=data, f_exp=lambda_arr[i])
    p_i = (1 - p_i)*100
    plt.plot(E, lambda_arr[i], "--", label = "{}, p = {:.2f}%".format(labels[i],p_i), color = colours[i])  

#plt.plot(E, lambda_initial, "-", color = "pink", label = "Initial guess, p = {:.2f}".format(p))
plt.fill_between(E,y_up, y_down, color = "red", alpha = 1, label = "Max. error")#),label = "$\u03B8_{{{}}}= {{{:.3f}}}^{{{:.3f}}}_{{{:.3f}}}$ $\u0394 m^{}_{{{}}} = {{{:.2f}}}^{{{:.2f}}}_{{{:.2f}}}·10^{{{}}}$, $\u03B1 = {{{:.3f}}}^{{{:.3f}}}_{{{:.3f}}}$".format(23,theta_23[0],theta_23[1],theta_23[2],2,23,dm_23_squ[0]*1e3,dm_23_squ[1]*1e3,dm_23_squ[2]*1e3, -3, alpha[0], alpha[1], alpha[2]))

 
plt.bar(x = E, height = data, width = 0.05, label = "Observed data", color = "grey")
plt.legend()
    
#%%   











