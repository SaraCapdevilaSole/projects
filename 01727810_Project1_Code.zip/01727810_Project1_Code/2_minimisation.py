"""
Project 1 - CP code
The data file: contains the observed number of muon neutrino events
"""
import numpy as np
import matplotlib.pyplot as plt
import CP1_tools

data = CP1_tools.open_file("Data to Fit")
    
E_max = 10 #GeV
E_min = 0
N = 200

dE = (E_max - E_min) / N
E = np.arange(E_min + dE, E_max + dE, dE)

theta_23 = np.pi/4 #rads
dm_23_squ = 2.4e-3 #(eV)^2 #as theta increase oscillation increases through a larger range of Energies
L = 295 #Km

#%% - trying out methods on data
# - Newton method
theta = 0.5 #theta_guess
mass = 0.0026
d_theta = 1e-4
d_mass = 1e-6

x_n, theta_N, mass_N = CP1_tools.Newton(theta, mass, L, E, d_theta, d_mass)
#94 [0.71386025 0.00259955]
#%%
theta = 0.5 #theta_guess
mass = 0.002

x_nm, theta_Nm, mass_Nm = CP1_tools.Newton_2(theta, mass, L, E, d_theta, d_mass)
#5179 [0.71216678 0.00259167]
plt.plot(theta_Nm, mass_Nm)
#5513 [0.71271874 0.00259531]
#%%
x = x_n
d_theta, d_mass = [1e-4, 1e-6]
y_tt = CP1_tools.FD_tt(x[0], x[1], L, E, d_theta)
y_mm = CP1_tools.FD_mm(x[0], x[1], L, E, d_mass)
y_tm = CP1_tools.FD_tm(x[0], x[1], L, E,d_theta, d_mass) #x_n[0], x_n[1], x_n[2]

H = np.zeros((2,2)) 
H[0,0] = y_tt
H[0,1] = H[1,0] = y_tm
H[1,1] = y_mm

H_inv = np.linalg.inv(H) #making sure thats + definite
std = np.sqrt([H_inv[0,0], H_inv[1,1]])
print(std)
#print(H_inv)
print(CP1_tools.Positive_def(H_inv))
print(H_inv[0,1]/(std[0]*std[1]))
#%%
print(CP1_tools.Parabolic_error_theta(x_n[0] - 0.1, x_n[0], x_n[0], x_n[0] + 0.1, x_n[0], x_n[1], L, E))
"""[0.7121667803162093, -0.010049095699664501, 0.011570211578970313]"""
#%%
print(CP1_tools.Parabolic_error_mass(x_n[1] - 1e-4, x_n[1], x_n[1], x_n[1] + 1e-4, x_n[0], x_n[1], L, E))
"""[0.0025916701912971274, -4.310809009635706e-05, 5.205716247097883e-05]"""
#%% - Gradient method
theta = 0.5 #theta_guess
mass = 0.002#0.001
d_theta = 1e-4
d_mass = 1e-6

x_n, theta_G, mass_G = CP1_tools.Gradient_method(theta, mass, L, E, d_theta, d_mass)
print(x_n)    

plt.plot(theta_G, mass_G)
#0.7125527  0.00260154] 6631 iterations
#%%
print(CP1_tools.Parabolic_error_theta(x_n[0] - 0.2, x_n[0], x_n[0], x_n[0] + 0.2, x_n[0], x_n[1], L, E))
"""[0.7125525549090379, -0.009782684966292421, 0.01210860038863315]"""
#%%
print(CP1_tools.Parabolic_error_mass(x_n[1] - 2e-4, x_n[1], x_n[1], x_n[1] + 2e-4, x_n[0], x_n[1], L, E))
"""[0.0026015398771969843, -5.049273045609325e-05, 4.1709912640776337e-05]"""
#%%
theta = 0.5 #theta_guess
mass = 0.002#0.001
d_theta = 1e-4
d_mass = 1e-6
#momentum p = 0.5
x_n_m, theta_Gm, mass_Gm = CP1_tools.Gradient_method2(theta, mass, L, E, d_theta, d_mass)
print(x_n_m) 
#3764 [0.71320597 0.00260234]   
#%%
momentum = 0.7
x_n_m0, theta_Gm0, mass_Gm0 = CP1_tools.Gradient_method2(theta, mass, L, E, d_theta, d_mass, momentum)
#2451 [0.71346942 0.00260266]
#%%
momentum = 0.8
x_n_me, theta_Gm_e, mass_Gm_e = CP1_tools.Gradient_method2(theta, mass, L, E, d_theta, d_mass, momentum)
#1727 [0.71360152 0.00260283]
#%%
momentum = 0.9
x_n_m1, theta_Gm1, mass_Gm1 = CP1_tools.Gradient_method2(theta, mass, L, E, d_theta, d_mass, momentum)
#911 [0.71373837 0.00260299]
#%%
momentum = 0.95
x_n_m2, theta_Gm2, mass_Gm2 = CP1_tools.Gradient_method2(theta, mass, L, E, d_theta, d_mass, momentum)
#214 [1.19275014 0.00887345] - overshooting to another local minima
#%%
n = [3764, 2451, 1727, 911, 214]
err_t = abs(([x_n_m[0],  x_n_m0[0], x_n_me[0],  x_n_m1[0], x_n_m2[0]] - x_n[0])/x_n[0]) * 100
err_m = abs(([x_n_m[1],  x_n_m0[1],x_n_me[1], x_n_m1[1], x_n_m2[1]] - x_n[1])/x_n[1]) * 100
err_mean = [np.mean([err_t[i], err_m[i]]) for i in range(len(err_t))]
labels = [0.5,0.7,0.8,0.9,0.95]
colours = ["orange", "red", "blue", "green", "brown"]
for i in range(len(labels)):
    plt.plot(n[i], err_t[i], 'x', color = colours[i])
    plt.plot(n[i], err_m[i], '.', color = colours[i])
    plt.plot(n[i], err_mean[i], 'o', color = colours[i], label = "p={}".format(labels[i]))
    plt.legend()
CP1_tools.plot_event([], [], "iterations", "% error from Gradient", "")
#%%
plt.plot(theta_Gm_e, mass_Gm_e)
plt.plot(theta_Gm0, mass_Gm0)
#%%
fig, axs = plt.subplots(2, sharex = True)
plt.subplots_adjust(hspace=0.1, top = 1.3)

axs[0].plot(theta_G, label = "Gradient with $p=0$")
axs[0].plot(theta_Gm, label = "Gradient with $p=0.5$")
axs[0].plot(theta_Gm0, label = "Gradient with $p=0.7$")
axs[0].plot(theta_Gm_e, label = "Gradient with $p=0.8$")
axs[0].plot(theta_Gm1, label = "Gradient with $p=0.9$")
axs[0].plot(theta_Gm2, label = "Gradient with $p=0.95$")
plt.legend()
#axs[0].grid()
axs[0].set_ylim([0.5,0.75])
axs[0].set_ylabel('$\u03F4_{23}$')
fig.legend(loc="best")

axs[1].plot(mass_G, label = "Gradient with $p=0$")
axs[1].plot(mass_Gm, label = "Gradient with $p=0.5$")
axs[1].plot(mass_Gm0, label = "Gradient with $p=0.7$")
axs[1].plot(mass_Gm_e, label = "Gradient with $p=0.8$")
axs[1].plot(mass_Gm1, label = "Gradient with $p=0.9$")
axs[1].plot(mass_Gm2, label = "Gradient with $p=0.95$")
axs[1].set_ylim([0.0022,0.00265])
#axs[1].grid()
axs[1].set_xlabel("Iteration")
axs[1].set_ylabel('$\u0394 m^{2}_{23}$')



#%% - Quasi Newton
theta = 0.5#0.7 #theta_guess
mass = 0.002
d_theta = 1e-4
d_mass = 1e-6


x_qN, theta_qN, mass_qN = CP1_tools.Newton_Quasi(theta, mass, L, E, d_theta, d_mass)
print(x_qN)

plt.plot(theta_qN, mass_qN)
#[0.7137512  0.00260301] 9947
#%%
print(CP1_tools.Parabolic_error_theta(x_qN[0] - 0.4, x_qN[0], x_qN[0], x_qN[0] + 0.4, x_qN[0], x_qN[1], L, E))
"""[0.7137510660912865, -0.010816487263594188, 0.010976944300721714]"""
#%%
print(CP1_tools.Parabolic_error_mass(x_qN[1] - 2e-4, x_qN[1], x_qN[1], x_qN[1] + 2e-4, x_qN[0], x_qN[1], L, E))
"""[0.0026030096562353507, -4.9336218069626243e-05, 4.1331544195404805e-05]"""
#%%
dm_23_squ_array = np.linspace(0.002, 0.0031,50)#0.005, 50)
theta_23_array = np.linspace(0.56,0.81,50)#0, np.pi/2, 50)

NLL_tot = np.zeros((len(theta_23_array),len(dm_23_squ_array)))

for i in range(len(theta_23_array)):
    for j in range(len(dm_23_squ_array)):
        NLL_tot[i,j] = CP1_tools.NLL(theta_23_array[j], dm_23_squ_array[i], L, E)
        
fig = plt.figure()
#fig,ax=plt.subplots(1,1)
#ax.scatter3D(dm_23_squ_array, theta_23_array, NLL_tot, c=NLL_tot, cmap='Greens')
#plt.contour(X, Y, NLL_tot, c=NLL_tot)

#%%
x_mass = [0.002, 0.003, 0.004] #[0.003, 0.002, 0.004]
x_theta = [0.2, 0.5, 0.7] #[0,0.5,0.7]
all_theta_1, all_mass_1 = CP1_tools.Univariate_method(x_theta, x_mass, L, E)
print(all_theta_1[-1], all_mass_1[-1])
#%%
X, Y = np.meshgrid(theta_23_array, dm_23_squ_array)
Z = NLL_tot
fig,ax=plt.subplots(1,1)
cp = ax.contourf(X, Y, Z, 100, cmap='pink')
fig.colorbar(cp, label = "$\it{NLL}$") # Add a colorbar to a plot
#ax.set_title('NLL of variables')
ax.set_ylabel('$\u0394 m^{2}_{23}$')
ax.set_xlabel('$\u03F4_{23}$')

#plt.plot(theta_Gm1, mass_Gm1,label = "Gradient p = 0.9")
plt.plot(theta_Nm, mass_Nm, label = "Newton modified")
plt.plot(all_theta_1, all_mass_1, "black", color = "white", label = "Univariate")#, label = "h")
plt.plot(theta_N, mass_N, label = "Newton")
#plt.plot(theta_G, mass_G,label = "Gradient")
plt.plot(theta_Gm_e, mass_Gm_e,label = "Gradient p = 0.8")
plt.plot(theta_qN, mass_qN,"--" , label = "Newton Quasi", color = "red")

plt.legend()
plt.ylim([0.002,0.0031])
plt.xlim([0.56,0.81])
plt.show()
#%% - all method summary:
"""
With covariance matrix:
Newton:
First method: (not valid as very close to min. for first guess)
0.7137805 -0.011091 + 0.0106, standard deviation = 1.14549578e-02
0.00259947 -4.594189e-05 + 4.4969397e-05, standard deviation = 4.66160652e-05

Second method:
[0.7121667803162093, -0.010049095699664501, 0.011570211578970313], standard deviation = 1.14611531e-02
[0.0025916701912971274, -4.310809009635706e-05, 5.205716247097883e-05], standard deviation = 4.97027787e-05

Gradient:
[0.7125523183489874, -0.009782491646718072, 0.012108834155177828], standard deviation = 1.1427164e-02
[0.0026015395862317805, -5.0492965979915486e-05, 4.1709988209279614e-05], standard deviation = 4.6115679e-05

Quasi Newton:
[0.7137510660912865, -0.010816487263594188, 0.010976944300721714], standard deviation = 1.14440765e-02
[0.0026030096562353507, -4.9336218069626243e-05, 4.1331544195404805e-05], standard deviation = 4.55816590e-05
"""

theta_mean = theta_Gm[-1]
#theta_std = np.std([t_N, t_G, t_QN])

mass_mean = mass_Gm[-1]
#mass_std =  np.std([m_N, m_G, m_QN])

print(theta_mean, mass_mean)

#%% - calculating the correlation - qN
#theta_mean = 0.7137510660912865
theta_std = 0.012 #average of uncertainties
#mass_mean = 0.0026030096562353507
mass_std = 0.05e-3

theta_circle = []
mass_circle = []
for i in range(100000):
    print(i)
    mass_new =  np.random.normal(mass_mean, mass_std)
    theta_new = np.random.normal(theta_mean, theta_std)
    NLL_comp = CP1_tools.NLL_function_err(theta_new, mass_new, theta_mean, mass_mean, L, E)

    if abs(NLL_comp) < 0.01:
        theta_circle.append(theta_new)
        mass_circle.append(mass_new)
        print("yes")

#%%
mass_circle = np.array(mass_circle)
theta_circle = np.array(theta_circle)

mass_min = mass_mean #mass_circle[np.argmin(theta_circle)]
mass_left = min(mass_circle)
mass_right = max(mass_circle)
mass_err_minus = mass_left - mass_min
mass_err_plus = mass_right - mass_min 

print(mass_min*1e3, mass_err_plus*1e3, mass_err_minus*1e3, "e-3")

theta_min = theta_mean #theta_circle[np.argmin(mass_circle)]
theta_left = min(theta_circle)
theta_right = max(theta_circle)
theta_err_minus = theta_left - theta_min
theta_err_plus = theta_right - theta_min
print(theta_min, theta_err_plus, theta_err_minus)

#%%
params = {'legend.fontsize': 'x-large',
          'figure.figsize': (8, 5),
         'axes.labelsize': 'x-large',
         'axes.titlesize':'x-large',
         'xtick.labelsize':'x-large',
         'ytick.labelsize':'x-large'}
plt.rcParams.update(params)

plt.plot(theta_circle, mass_circle, '.', color = "brown", label = "$\u0394 m^{}_{{{}}} = {:.3f}^{{{:.3f}}}_{{{:.3f}}}x10^{{{}}} (eV/c^{})^{}, \u03F4_{{{}}} = {:.3f}^{{{:.3f}}}_{{{:.3f}}}$".format(2, 23, mass_min*1e3,mass_err_plus*1e3, mass_err_minus*1e3, -3, 2, 2, 23, theta_min, theta_err_plus, theta_err_minus))
plt.grid()
plt.xlabel("$\u03F4_{23}$")
plt.ylabel("$\u0394 m^{2}_{23}$")
CP1_tools.plot_event([],[],"$\u03F4_{23}$","$\u0394 m^{2}_{23}$","")















