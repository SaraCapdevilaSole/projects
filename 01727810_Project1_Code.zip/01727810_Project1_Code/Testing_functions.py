"""
Testing file
"""
import numpy as np
import matplotlib.pyplot as plt
import CP1_tools
"""
1D testing
"""
#%%
def function_prob_test(theta_23, dm_23_squ):
    return 1 - np.sin(2*theta_23)**2

x = CP1_tools.Parabolic_min_test1(function_prob_test, [0.5,0.9,1.2] , 2)
print("pi/4 %",x[0]%(np.pi/4))
#%% - testing univariate method & parabolic methods
def func1d(x1, a):
    return (x1-a)**2 

def func(x1,x2):
    return (x1-5)**2 + (x2-3)**2

x1_arr = [3,6,8]
x2_arr = [2,2.5,4.3]
a = 0.1
x3, x_all = CP1_tools.Parabolic_min_test1(func1d, x1_arr, a, 1e-5)
print(x3)
x2_min, x1_min = CP1_tools.Univariate_method_test(func, x1_arr, x2_arr)
print(x2_min, x1_min)
#%%
"""
2D testing
"""
#%% - Testing 2d function 1
def function(x, y):
    return 4*x**2 + 3*y**2 + 2

x = np.arange(-30,31)
y = np.arange(-30,31)
z = np.zeros((61,61))
for i in x:
    for j in y:
        z[i+30,j+30] = function(i,j)
#%% - calculating the gradient
print(CP1_tools.gradient_f_test(function, theta = 2, mass = 2, d_theta = 1e-6, d_mass = 1e-6))
#gives gradient of 16, 12 - gradient works well
#%% - calculating minimum using grad function
x_G, x1_array_G, x2_array_G = CP1_tools.Gradient_method_test(function, theta = 30, mass = 30, d_theta = 1e-6, d_mass = 1e-6)
print(x_G)
#%%
x_Gm, x1_array_Gm, x2_array_Gm = CP1_tools.Gradient_method2_test(function, theta = 30, mass = 30, d_theta = 1e-6, d_mass = 1e-6, momentum = 0.9)
print(x_Gm)
#%%
x_n, theta_N, mass_N = CP1_tools.Newton_test(function, theta = 30, mass = 30, d_theta = 1e-4, d_mass = 1e-4)
print(x_n)
#%% - now Newton test
x_n, theta_Nm, mass_Nm = CP1_tools.Newton2_test(function, theta = 30, mass = 30, d_theta = 1e-4, d_mass = 1e-4)
print(x_n)
#%% - Newton Quasi method 
x_qn, x1_array_nq, x2_array_nq = CP1_tools.Newton_Quasi_test(function, theta = 30, mass = 30, d_theta = 1e-4, d_mass = 1e-4)
print(x_qn)
#%% - plot
X, Y = np.meshgrid(x, y)
Z = z
fig,ax=plt.subplots(1,1)
cp = ax.contourf(X, Y, Z, 60, cmap='copper')
#plt.plot(np.arange(-10,10), np.zeros(20), "--", color = "grey")
plt.plot(np.zeros(20), np.arange(-10,10), "--", color = "grey")
plt.plot(x1_array_G, x2_array_G, color = "white")#, label = "Gradient")
plt.plot(x1_array_Gm, x2_array_Gm, color = "white", label = "Gradient (with p=0.9)")
plt.plot(theta_N, mass_N, label = "(Modified) Newton", color = "yellow")
plt.plot(theta_Nm, mass_Nm, color = "yellow")#, label = "Newton"
plt.plot(x1_array_nq, x2_array_nq,'--', label = "Quasi Newton", color = "red")
fig.colorbar(cp, label = "f(x,y)") # Add a colorbar to a plot
plt.plot([-30,30],[0,0], "--", color = "grey", label = "$f_{min}(0,0)=0$")
plt.plot([0,0],[-30,30], "--", color = "grey")
plt.legend(loc = "lower left")
plt.xlabel("x")
plt.ylabel("y")
#plt.ylim([-10,10])
#plt.xlim([-10,10])
#plt.title("Test function $f(x,y) = 4x^{2} + 3y^{2} + 2$")
#%%
def function2(x,y):
    return 2*x**2 + 2*x*y + 2*y**2 - 6*x


x = np.arange(-10,11)
y = np.arange(-10,11)
z = np.zeros((len(x),len(y)))
for i in range(len(x)):
    for j in range(len(y)):
        z[j,i] = function2(x[i],y[j])
#%% - calculating minimum using grad function
x_G, x1_array_G, x2_array_G = CP1_tools.Gradient_method_test(function2, theta = 10, mass = 10, d_theta = 1e-6, d_mass = 1e-6)
print(x_G)
#%%
x_Gm, x1_array_Gm, x2_array_Gm = CP1_tools.Gradient_method2_test(function2, theta = 10, mass = 10, d_theta = 1e-6, d_mass = 1e-6, momentum = 0.7)
print(x_Gm)
#%%
x_n, theta_N, mass_N = CP1_tools.Newton_test(function2, theta = 10, mass = 10, d_theta = 1e-6, d_mass = 1e-6)
print(x_n)
#%% - Newton Quasi method 
x_qn, x1_array_nq, x2_array_nq = CP1_tools.Newton_Quasi_test(function2, theta = 30, mass = 30, d_theta = 1e-6, d_mass = 1e-6)
#%%
theta_uN, mass_uN = CP1_tools.Univariate_method_test(function2, [8,2,20], [14,5,15], eps_0 = 1e-3)
print(theta_uN, mass_uN)
#%%
X, Y = np.meshgrid(x, y)
Z = z
fig,ax=plt.subplots(1,1)
cp = ax.contourf(X, Y, Z, 30, cmap='copper')
#plt.plot(np.arange(-10,10), np.zeros(20), "--", color = "grey")
#plt.plot(np.zeros(20), np.arange(-10,10), "--", color = "grey")
#plt.plot(x1_array_G, x2_array_G, color = "white")#, label = "Gradient")
plt.plot(x1_array_Gm, x2_array_Gm, color = "white", label = "Gradient (with p=0.7)")
plt.plot(theta_uN, mass_uN, color = "purple", label = "Univariate")
plt.plot(theta_N, mass_N, label = "(Modified) Newton", color = "yellow")
plt.plot(x1_array_nq, x2_array_nq,'-', label = "Quasi Newton", color = "red")
fig.colorbar(cp, label = "f(x,y)") # Add a colorbar to a plot
plt.plot([-30,30],[-1,-1], "--", color = "grey", label = "$f_{min}(2,-1)=0$")
plt.plot([2,2],[-10,10], "--", color = "grey")
plt.xlim([-10, 10])
plt.ylim([-10,10])
plt.legend(loc = "lower left")
plt.xlabel("x")
plt.ylabel("y")
#%%
"""for i in x1_array:
    if i > 2*np.pi:
        i = (np.array(i) -2) / (2*np.pi ) + 2
for i in theta_N:
    if i > 2*np.pi:
        i = (np.array(theta_N)-2) / (2*np.pi ) + 2"""
#%%
def function3(x,y):
    return 5*np.sin(x) + 3*abs(y)

#%% - calculating minimum using grad function
x_G, x1_array_G, x2_array_G = CP1_tools.Gradient_method_test(function3, theta = 10, mass = 10, d_theta = 1e-6, d_mass = 1e-6)
print(x_G)
#%%
x_Gm, x1_array_Gm, x2_array_Gm = CP1_tools.Gradient_method2_test(function3, theta = 7.5, mass = 5, d_theta = 1e-6, d_mass = 1e-6, momentum = 0.9)
print(x_Gm)
#%% - plot
x = np.arange(-30,30)
y = np.arange(-30,30)
z = np.zeros((len(x),len(y)))
for i in range(len(x)):
    for j in range(len(y)):
        z[j,i] = function3(x[i],y[j])
        
X, Y = np.meshgrid(x, y)
Z = z
fig,ax=plt.subplots(1,1)
cp = ax.contourf(X, Y, Z, 50, cmap='copper')
#plt.plot(np.arange(-10,10), np.zeros(20), "--", color = "grey")
#plt.plot(np.zeros(20), np.arange(-10,10), "--", color = "grey")
plt.plot(x1_array_G, x2_array_G, color = "white")#, label = "Gradient")
plt.plot(x1_array_Gm, x2_array_Gm, color = "white", label = "Gradient (with p=0.9)")
fig.colorbar(cp, label = "f(x,y)") # Add a colorbar to a plot
#plt.plot([-30,30],[0,0], "--", color = "grey", label = "$f_{min}(0,0)=0$")
#plt.plot([0,0],[-30,30], "--", color = "grey")
plt.xlim([-10, 10])
plt.ylim([-6,6])
plt.legend(loc = "lower left")
plt.xlabel("x")
plt.ylabel("y")
#%% - other testing: secant method
y = 0
print(CP1_tools.Secant_test(-10,10,y,function2))
y =3.2
print(CP1_tools.Secant_test(-10,10,y,function2))
#%% - testing derivatives
dx = 1e-5
#def function(x,y,z):
#    return (x*y*z)**3

def function(x,y,z):
    return np.sin(x)*np.cos(y) + np.exp(z**2)

x = [2*np.pi,np.pi/2,0]
y_tt = CP1_tools.FD_tt_3D(x[0], x[1], x[2], dx, function)
y_mm = CP1_tools.FD_mm_3D(x[0], x[1], x[2], dx, function)
y_aa = CP1_tools.FD_aa_3D(x[0], x[1], x[2], dx, function)
y_tm = CP1_tools.FD_tm_3D(x[0], x[1], x[2], dx, dx, function)
y_ta =CP1_tools.FD_ta_3D(x[0], x[1], x[2], dx, dx, function)
y_ma =CP1_tools.FD_ma_3D(x[0], x[1], x[2], dx, dx, function)

H = np.zeros((3,3))
H[0,0] = y_tt
H[0,1] = H[1,0] = y_tm
H[0,2] = H[2,0] = y_ta
H[1,2] = H[2,1] = y_ma
H[1,1] = y_mm
H[2,2] = y_aa
print(H)
#%% - test, 
def f(x0, x1, x2):
	return x0**2 + (2*x1-3)**2 + np.sin(x2)**2

T = [20,0]
dT = 0.5


x_0 = [2,4,0.5] #inital points
x_norm = [1,1,1]


N = 10000

x_min_t, E_final_t, x1_test, x2_test, x3_test, E_test, T_test = CP1_tools.Simulated_annealing(f, x_0, N, dT, T, x_norm)
print('Done!')
print(x_min_t)
#%% - normalising as x2 has many local minima (integer multiples of pi)
for i in range(len(x3_test)):
    while abs(x3_test[i]) > np.pi:
        x3_test[i] /= np.pi
if abs(x_min_t[2])  >np.pi:
    x_min_t[2] /= np.pi
print(x_min_t)        
#%%
"""
To only plot the minimas accepted, please comment out the .append(canditates) under "elif dE <= 0:"
"""
plt.plot(x1_test, label = "$x_{0} = 0$") #x0**2 + (2*x1-3)**2 + np.sin(x2)**2
plt.plot(x2_test, label = "$x_{1} = 1.5$")
plt.plot(x3_test, label = "$x_{2} = n \pi$")
plt.grid()
#plt.ylim([-5,5])
plt.xlabel('Iteration Number')
plt.ylabel('x variables')
CP1_tools.plot_event([],[],'Iteration Number', 'x variables', '')
plt.show()
















