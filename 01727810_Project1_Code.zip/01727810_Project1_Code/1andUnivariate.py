#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1D and Univariate minimisation
"""
import numpy as np
import matplotlib.pyplot as plt
import CP1_tools

data = CP1_tools.open_file("Data to Fit")
    
E_max = 10 #GeV
E_min = 0
N = 200

dE = (E_max - E_min) / N
E = np.arange(E_min + dE, E_max + dE, dE)

theta_23 = np.pi/4 #rads
dm_23_squ = 2.4e-3 #(eV)^2 #as theta increase oscillation increases through a larger range of Energies
L = 295 #Km

E = np.arange(E_min + dE, E_max + dE, dE) #E = np.arange(E_min, E_max, dE) #note: what happens at E=0?
P_mu = []
for E_i in E:
    P_mu.append(CP1_tools.oscillation_prob(theta_23, dm_23_squ, L, E_i))

#
theta_23_array = np.linspace(0, np.pi/2, len(E))

#print(CP1_tools.NLL(np.pi/4 ,2.4e-3, 295, E))
Neg_LL = []
for theta_23_i in theta_23_array:
    Neg_LL.append(CP1_tools.NLL(theta_23_i, dm_23_squ, L, E))

x_theta = [0.0,0.5,0.7]#[0.7,0.4,0.6]
x_theta2 = [1.5,0.5,1]

theta_min, theta_err, theta_arr = CP1_tools.Parabolic_min_theta(x_theta, dm_23_squ, L, E)
theta2_min, theta2_err, theta2_arr = CP1_tools.Parabolic_min_theta(x_theta2, dm_23_squ, L, E)
plt.title("Minimum of $\u03B8_{{{}}} = {:.3f} \pm {:.3f}$ and ${:.3f} \pm {:.3f}$ rads".format(23, theta_min, theta_err, theta2_min, theta2_err))
CP1_tools.plot_event(theta_23_array, Neg_LL, "$\u03B8_{{{23}}}$", "NLL", "")
#%%
dm_23_squ_array = np.linspace(0, 0.01, len(E))

#print(CP1_tools.NLL(np.pi/4 ,2.4e-3, 295, E))
Neg_LL = []
for dm_23_squ_array_i in dm_23_squ_array:
    Neg_LL.append(CP1_tools.NLL(theta_23, dm_23_squ_array_i, L, E))

x_mass = [0.002, 0.003, 0.004]

mass_min, mass_err, mass_arr = CP1_tools.Parabolic_min_mass(x_mass, theta_23, L, E)
plt.title("Minimum of $\u0394 m_{{{}}}^2 = {:3f} \pm {:3f} Kg^{}$".format(23,mass_min, mass_err,2))
CP1_tools.plot_event(dm_23_squ_array, Neg_LL, "$\u0394 m_{{{}}}^2$", "NLL", "")
#%% - error in parabolic minimisation
print(CP1_tools.Parabolic_error_theta(theta_min - 0.4, theta_min, theta_min, theta_min + 0.4, theta_min, mass_min, L, E))
#%%
print(CP1_tools.Parabolic_error_theta(theta2_min - 0.4, theta2_min, theta2_min, theta2_min + 0.4, theta2_min, mass_min, L, E))
#%%
print(CP1_tools.Parabolic_error_mass(mass_min - 2e-4, mass_min, mass_min, mass_min + 2e-4, theta_min, mass_min, L, E))
#%%
plt.plot(dm_23_squ_array, [CP1_tools.NLL_function_err(theta_min, m, theta_min, mass_min, L, E) for m in dm_23_squ_array])
#plt.ylim([-0.6,0])
#plt.xlim([0.002,0.003])
plt.grid()
#%% - as theta approaches

theta_min_array = np.array([1/4 - 0.02, 1/4 - 0.01, 1/4 - 0.001, 1/4]) * np.pi 
labels = [0.05,0.01,0.001,0]
colours = ["#ffae00", "#ff5700", "#1a7100","#8e6100"]
i = 0
for theta_min in theta_min_array:
    plt.plot(theta_23_array, [CP1_tools.NLL_function_err(t, mass_min, theta_min, mass_min, L, E) for t in theta_23_array], label = "$\u03B8_{{{}}}=\u03C0/{} - {}$".format(23,4,labels[i]), color = colours[i])
    i += 1

plt.legend()
plt.ylim([-20,50])
plt.xlim([0.4,1.2])
CP1_tools.plot_event([], [], "$\u03F4_{23}$", "NLL", "")

#%%
"""
Summary of 1D minimisation:
Theta alone: 0.712 pm 0.11 and 0.859 pm 0.011 
mass alone: 0.002644 pm 0.000017 kg^2
errors with lagrange curvature 1/second derivative^^

With NLL(u) - (NLL + 0.5), errors= 
Theta1 = [0.7118005503865811, -0.007356516203119723, 0.007356516233086641]
Theta2 = [0.8590062006859615, -0.007350254236873521, 0.007350254017511326]

Mass = [0.0026436630799476202, -0.00013442383749654157, 1.6221709476857762e-05]

Different errors in different directions, as NLL curve shape is not symmetric about minimum
"""
#%%
dm_23_squ_array = np.linspace(0.002, 0.003, 100) #np.linspace(0, 0.005, 100)
theta_23_array = np.linspace(0.6, 0.95, 100) #np.linspace(0, np.pi/2, 100)

NLL_tot = np.zeros((len(theta_23_array),len(dm_23_squ_array)))

for i in range(len(theta_23_array)):
    for j in range(len(dm_23_squ_array)):
        NLL_tot[i,j] = CP1_tools.NLL(theta_23_array[j], dm_23_squ_array[i], L, E)
        
#%% - Univariate method: theta first
x_mass = [0.002, 0.003, 0.004] #[0.003, 0.002, 0.004]
x_theta_1 = [0.2, 0.5, 0.7] #[0,0.5,0.7]
x_theta_2 = [0.8, 0.85,0.9]
all_theta_1, all_mass_1 = CP1_tools.Univariate_method(x_theta_1, x_mass, L, E)
x_mass = [0.002, 0.003, 0.004]
all_theta_2, all_mass_2 = CP1_tools.Univariate_method(x_theta_2, x_mass, L, E)
#print(all_theta_1[-1], all_mass_1[-1])
print(CP1_tools.NLL(all_theta_1[-1], all_mass_1[-1], L, E))
#print(all_theta_2[-1], all_mass_2[-1])
print(CP1_tools.NLL(all_theta_2[-1], all_mass_2[-1], L, E))

# - Both Univariate 2D minimisers
fig = plt.figure()

X, Y = np.meshgrid(theta_23_array, dm_23_squ_array)
Z = NLL_tot
fig,ax=plt.subplots(1,1)
cp = ax.contourf(X, Y, Z, 100, cmap='pink')
plt.xlim([0.6,0.95])
plt.ylim([0.002,0.003])
#CS = ax.contour(X, Y, Z)
#ax.clabel(CS, inline=1, fontsize=10)
fig.colorbar(cp,label = "$\it{NLL}$") # Add a colorbar to a plot
ax.set_title('NLL of variables')
ax.set_ylabel('mass squared (kg^2)')
ax.set_xlabel('theta (rads)')
plt.plot(all_theta_1, all_mass_1, "black", color = "white")
plt.plot(all_theta_2, all_mass_2, color = "white")
plt.show()
#plt.plot(NLL_mass, NLL_theta)
"""
Same result if you do one variable before the other
"""
#%% - error calculation
#error on theta1
theta_min = all_theta_1[-1]
mass_min = all_mass_1[-1]
print(CP1_tools.Parabolic_error_theta(theta_min - 0.1, theta_min, theta_min, theta_min + 0.1, theta_min, mass_min, L, E))
"""[0.7148240151511177, -0.011834849251389001, 0.010053960338588297]"""
#%%
theta2_min = all_theta_2[-1]
mass_min = all_mass_2[-1]
print(CP1_tools.Parabolic_error_theta(theta2_min - 0.05, theta2_min, theta2_min, theta2_min + 0.05, theta2_min, mass_min, L, E))
"""[0.8560208754381028, -0.010093902130305477, 0.011786860606923133]"""
#%%
theta_min = all_theta_1[-1]
mass_min = all_mass_1[-1]
print(CP1_tools.Parabolic_error_mass(mass_min - 2e-4, mass_min, mass_min, mass_min + 2e-4, theta_min, mass_min, L, E))
"""[0.0026043177723097995, -4.8360679333705504e-05, 4.1000726063950953e-05]"""
#%%
theta_min = all_theta_2[-1]
mass_min = all_mass_1[-1]
print(CP1_tools.Parabolic_error_mass(mass_min - 2e-4, mass_min, mass_min, mass_min + 2e-4, theta_min, mass_min, L, E))
"""[0.0026043177723097995, -4.846275802200713e-05, 4.095719137052088e-05]"""











